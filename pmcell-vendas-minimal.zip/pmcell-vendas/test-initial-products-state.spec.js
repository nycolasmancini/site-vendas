/**
 * Testes TDD para problema de produtos desaparecendo temporariamente
 * 
 * PROBLEMA: Site fica sem produtos e depois atualiza para mostrar o que está na base de dados
 * CAUSA: Estado inicial vazio + race condition + falta de skeleton loader
 */

const { test, expect } = require('@playwright/test')

test.describe('Estado Inicial de Produtos - Prevenção de "Piscar"', () => {
  
  test('Produtos não devem "piscar" durante carregamento inicial', async ({ page }) => {
    // Simular conexão lenta
    await page.route('/api/products*', async route => {
      await new Promise(resolve => setTimeout(resolve, 2000)) // 2s delay
      return route.continue()
    })
    
    await page.goto('/')
    
    // Verificar que skeleton loader é mostrado imediatamente
    await expect(page.locator('[data-testid="products-skeleton"]')).toBeVisible()
    
    // Verificar que não há flash de "sem produtos"
    await expect(page.locator('[data-testid="no-products-message"]')).not.toBeVisible()
    
    // Aguardar produtos carregarem
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible({ timeout: 5000 })
    
    // Skeleton deve desaparecer
    await expect(page.locator('[data-testid="products-skeleton"]')).not.toBeVisible()
    
    // Produtos devem estar visíveis
    const productCount = await page.locator('[data-testid="product-card"]').count()
    expect(productCount).toBeGreaterThan(0)
  })
  
  test('Estado inicial deve diferenciar "carregando" de "vazio"', async ({ page }) => {
    await page.goto('/')
    
    // Estado inicial deve ser "carregando", não "vazio"
    const initialState = await page.evaluate(() => {
      return {
        loading: document.querySelector('[data-testid="loading"]') !== null,
        noProducts: document.querySelector('[data-testid="no-products"]') !== null,
        skeleton: document.querySelector('[data-testid="products-skeleton"]') !== null
      }
    })
    
    expect(initialState.loading || initialState.skeleton).toBe(true)
    expect(initialState.noProducts).toBe(false)
  })
  
  test('Cache local deve ser usado para estado inicial', async ({ page }) => {
    // Primeira visita - carregar produtos
    await page.goto('/')
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible()
    
    // Segunda visita - deve usar cache
    await page.reload()
    
    // Produtos devem aparecer imediatamente (do cache)
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible({ timeout: 1000 })
    
    // Verificar que não houve "piscar"
    const hasFlickered = await page.evaluate(() => {
      return window.performance.getEntriesByType('measure')
        .some(entry => entry.name === 'products-flicker')
    })
    
    expect(hasFlickered).toBe(false)
  })
  
  test('Auto-refresh não deve causar flicker', async ({ page }) => {
    await page.goto('/')
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible()
    
    // Contar produtos iniciais
    const initialCount = await page.locator('[data-testid="product-card"]').count()
    
    // Aguardar auto-refresh (11 segundos)
    await page.waitForTimeout(11000)
    
    // Produtos devem continuar visíveis sem piscar
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible()
    
    const finalCount = await page.locator('[data-testid="product-card"]').count()
    
    // Pode ter mudado quantidade, mas nunca deve ter ficado vazio
    expect(finalCount).toBeGreaterThan(0)
  })
})

module.exports = {
  testInitialProductsState: test
}