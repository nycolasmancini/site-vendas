# Credenciais de Admin - PMCELL

## Login do Painel Administrativo

**URL:** http://localhost:3000/admin/login

**Credenciais de Teste (quando o banco não está acessível):**
- **Email:** admin@pmcell.com.br
- **Senha:** admin123

## Observações:
- Estas credenciais funcionam apenas quando o banco de dados Supabase está inacessível
- Quando o banco estiver disponível, use as credenciais reais cadastradas no sistema
- O sistema detecta automaticamente se o banco está disponível ou não