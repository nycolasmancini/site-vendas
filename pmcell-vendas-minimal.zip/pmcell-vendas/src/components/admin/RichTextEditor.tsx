'use client'

import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Subscript from '@tiptap/extension-subscript'
import { useEffect } from 'react'
import { Bold, Italic, Heading2, Subscript as SubscriptIcon } from 'lucide-react'

interface RichTextEditorProps {
  content: string
  onChange: (html: string) => void
  placeholder?: string
  className?: string
}

const RichTextEditor = ({ content, onChange, placeholder, className }: RichTextEditorProps) => {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        // Desabilitar extensões que não vamos usar
        heading: {
          levels: [2], // Apenas H2 para títulos
        },
        strike: false,
        code: false,
        codeBlock: false,
        blockquote: false,
        horizontalRule: false,
        listItem: false,
        orderedList: false,
        bulletList: false,
      }),
      Subscript,
    ],
    content: content,
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none min-h-[120px] p-3',
      },
    },
    onUpdate: ({ editor }) => {
      const html = editor.getHTML()
      onChange(html)
    },
  })

  // Atualizar conteúdo quando o prop content mudar
  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content)
    }
  }, [content, editor])

  if (!editor) {
    return (
      <div className={`mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 ${className}`}>
        <div className="animate-pulse h-32 bg-gray-200 rounded"></div>
      </div>
    )
  }

  return (
    <div className={`border border-gray-300 rounded-md shadow-sm focus-within:ring-green-500 focus-within:border-green-500 ${className}`}>
      {/* Toolbar */}
      <div className="border-b border-gray-200 bg-gray-50 px-3 py-2 flex space-x-2">
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          className={`p-2 rounded-md hover:bg-gray-200 transition-colors ${
            editor.isActive('heading', { level: 2 }) 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-700'
          }`}
          title="Título (H2)"
        >
          <Heading2 className="w-4 h-4" />
        </button>
        
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`p-2 rounded-md hover:bg-gray-200 transition-colors ${
            editor.isActive('bold') 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-700'
          }`}
          title="Negrito"
        >
          <Bold className="w-4 h-4" />
        </button>
        
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`p-2 rounded-md hover:bg-gray-200 transition-colors ${
            editor.isActive('italic') 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-700'
          }`}
          title="Itálico"
        >
          <Italic className="w-4 h-4" />
        </button>
        
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleSubscript().run()}
          className={`p-2 rounded-md hover:bg-gray-200 transition-colors ${
            editor.isActive('subscript') 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-700'
          }`}
          title="Subscrito"
        >
          <SubscriptIcon className="w-4 h-4" />
        </button>
      </div>

      {/* Editor */}
      <div className="min-h-[120px]">
        <EditorContent 
          editor={editor} 
          placeholder={placeholder}
          className="prose-sm"
        />
      </div>
    </div>
  )
}

export default RichTextEditor