'use client'

import { useState, useCallback, useRef, useEffect } from 'react'

interface QuantityInputFieldProps {
  modelId: string
  defaultQuantity?: number
  onQuantityCommit: (modelId: string, quantity: number) => void
  onIncrement: () => void
  onDecrement: () => void
  isDisabled?: boolean
  className?: string
  showCurrentQuantity?: number // Para exibir quantidade do carrinho sem interferir no input
}

export const QuantityInputField = ({ 
  modelId, 
  defaultQuantity = 0,
  onQuantityCommit, 
  onIncrement, 
  onDecrement,
  isDisabled = false,
  className = '',
  showCurrentQuantity = 0
}: QuantityInputFieldProps) => {
  // Estado completamente local - não sincroniza automaticamente
  const [localValue, setLocalValue] = useState<string>('')
  const [isEditing, setIsEditing] = useState(false)
  const [lastCommittedValue, setLastCommittedValue] = useState(defaultQuantity)
  const inputRef = useRef<HTMLInputElement>(null)
  const isFirstRender = useRef(true)

  // Inicializar apenas na primeira renderização
  useEffect(() => {
    if (isFirstRender.current) {
      setLocalValue(showCurrentQuantity > 0 ? showCurrentQuantity.toString() : '')
      setLastCommittedValue(showCurrentQuantity)
      isFirstRender.current = false
    }
  }, [showCurrentQuantity])

  // Função para aplicar valor ao carrinho
  const commitValue = useCallback(() => {
    if (isEditing) {
      const numValue = Math.max(0, parseInt(localValue) || 0)
      onQuantityCommit(modelId, numValue)
      setLastCommittedValue(numValue)
      setIsEditing(false)
      
      // Atualizar valor local para refletir o que foi commitado
      setLocalValue(numValue > 0 ? numValue.toString() : '')
    }
  }, [isEditing, localValue, modelId, onQuantityCommit])

  // Função para obter valor de exibição
  const getDisplayValue = useCallback((): string => {
    if (isEditing) {
      return localValue
    }
    // Quando não está editando, mostrar quantidade atual do carrinho
    return showCurrentQuantity > 0 ? showCurrentQuantity.toString() : ''
  }, [isEditing, localValue, showCurrentQuantity])

  // Handlers de eventos
  const handleInputChange = useCallback((value: string) => {
    // Validar entrada - apenas números e string vazia
    if (value !== '' && (isNaN(Number(value)) || Number(value) < 0)) {
      return
    }
    
    setLocalValue(value)
    if (!isEditing) {
      setIsEditing(true)
    }
  }, [isEditing])

  const handleFocus = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
    e.target.select()
    setIsEditing(true)
    // Inicializar com valor atual se estava vazio
    if (localValue === '' && showCurrentQuantity > 0) {
      setLocalValue(showCurrentQuantity.toString())
    }
  }, [localValue, showCurrentQuantity])

  const handleBlur = useCallback(() => {
    commitValue()
  }, [commitValue])

  const handleKeyPress = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      commitValue()
      inputRef.current?.blur()
    }
  }, [commitValue])

  const handleDecrement = useCallback(() => {
    // Se estava editando, aplicar primeiro
    if (isEditing) {
      commitValue()
      // Aguardar um tick para garantir que o valor foi aplicado
      setTimeout(onDecrement, 0)
    } else {
      onDecrement()
    }
  }, [isEditing, commitValue, onDecrement])

  const handleIncrement = useCallback(() => {
    // Se estava editando, aplicar primeiro
    if (isEditing) {
      commitValue()
      // Aguardar um tick para garantir que o valor foi aplicado
      setTimeout(onIncrement, 0)
    } else {
      onIncrement()
    }
  }, [isEditing, commitValue, onIncrement])

  return (
    <div className={`flex items-center rounded-lg overflow-hidden shadow-sm border border-gray-200 bg-white ${className}`}>
      <button
        onClick={handleDecrement}
        disabled={isDisabled || showCurrentQuantity === 0}
        className="px-1.5 sm:px-3 py-1 sm:py-2 hover:bg-red-50 hover:text-red-600 text-gray-500 font-bold transition-all duration-200 ease-out disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-red-300 active:scale-95 text-sm sm:text-base"
      >
        −
      </button>
      <input
        ref={inputRef}
        type="number"
        value={getDisplayValue()}
        onChange={(e) => handleInputChange(e.target.value)}
        onBlur={handleBlur}
        onKeyPress={handleKeyPress}
        onFocus={handleFocus}
        disabled={isDisabled}
        className={`w-10 sm:w-16 text-center py-1 sm:py-2 text-xs sm:text-sm font-semibold border-x transition-all duration-200 ${
          isEditing 
            ? 'border-blue-400 bg-blue-50 focus:bg-blue-50 focus:ring-2 focus:ring-blue-400 focus:border-blue-500 shadow-inner text-blue-900' 
            : 'border-gray-200 bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-300'
        } focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed`}
        min="0"
        title={isEditing ? 'Digite a quantidade e pressione Enter ou clique fora para aplicar' : 'Clique para editar a quantidade'}
        placeholder={isEditing ? 'Qtd' : (showCurrentQuantity > 0 ? showCurrentQuantity.toString() : '0')}
      />
      <button
        onClick={handleIncrement}
        disabled={isDisabled}
        className="px-1.5 sm:px-3 py-1 sm:py-2 hover:bg-green-50 hover:text-green-600 text-gray-500 font-bold transition-all duration-200 ease-out focus:outline-none focus:ring-2 focus:ring-green-300 active:scale-95 text-sm sm:text-base disabled:opacity-50 disabled:cursor-not-allowed"
      >
        +
      </button>
    </div>
  )
}