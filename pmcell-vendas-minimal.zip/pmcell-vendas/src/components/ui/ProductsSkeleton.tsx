/**
 * Skeleton loader para prevenir "piscar" durante carregamento de produtos
 */

export function ProductsSkeleton() {
  return (
    <div 
      data-testid="products-skeleton"
      className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
    >
      {Array.from({ length: 8 }).map((_, index) => (
        <div 
          key={index}
          className="bg-white rounded-lg shadow-sm border animate-pulse"
        >
          {/* Imagem skeleton */}
          <div className="w-full h-48 bg-gray-200 rounded-t-lg"></div>
          
          {/* Conteúdo skeleton */}
          <div className="p-4 space-y-3">
            {/* Nome do produto */}
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            
            {/* Subnome */}
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            
            {/* Preço */}
            <div className="space-y-2">
              <div className="h-5 bg-gray-200 rounded w-1/3"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </div>
            
            {/* Botão */}
            <div className="h-10 bg-gray-200 rounded w-full"></div>
          </div>
        </div>
      ))}
    </div>
  )
}

export function ProductsSkeletonCompact() {
  return (
    <div 
      data-testid="products-skeleton-compact"
      className="space-y-4"
    >
      {Array.from({ length: 4 }).map((_, index) => (
        <div 
          key={index}
          className="bg-white rounded-lg shadow-sm border animate-pulse p-4"
        >
          <div className="flex gap-4">
            {/* Imagem skeleton */}
            <div className="w-20 h-20 bg-gray-200 rounded"></div>
            
            {/* Conteúdo skeleton */}
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              <div className="h-5 bg-gray-200 rounded w-1/3"></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}