import { NextResponse } from 'next/server'
import { ensureAllTablesExist, checkTableExists, clearTableCache } from '@/lib/table-sync'

export async function POST() {
  try {
    console.log('🔄 Iniciando sincronização manual do banco de dados...')
    
    // Limpar cache antes da verificação manual
    clearTableCache()
    
    // Verificar estado inicial das tabelas
    const tablesToCheck = ['Brand', 'Model', 'Product', 'Category', 'ProductModel']
    const tableStatus: Record<string, boolean> = {}
    
    for (const table of tablesToCheck) {
      tableStatus[table] = await checkTableExists(table)
      console.log(`📊 Tabela ${table}: ${tableStatus[table] ? '✅ Existe' : '❌ Não existe'}`)
    }
    
    // Executar sincronização completa
    const syncResult = await ensureAllTablesExist()
    
    if (syncResult) {
      // Verificar estado final
      const finalStatus: Record<string, boolean> = {}
      for (const table of tablesToCheck) {
        finalStatus[table] = await checkTableExists(table)
      }
      
      const createdTables = Object.entries(tableStatus)
        .filter(([table, existed]) => !existed && finalStatus[table])
        .length
      
      return NextResponse.json({
        success: true,
        message: `Sincronização concluída. ${createdTables} tabelas criadas.`,
        beforeSync: tableStatus,
        afterSync: finalStatus,
        createdTables
      })
    } else {
      return NextResponse.json({
        success: false,
        error: 'Falha na sincronização do banco',
        tableStatus
      }, { status: 500 })
    }
    
  } catch (error) {
    console.error('Erro na sincronização:', error)
    return NextResponse.json({
      success: false,
      error: 'Erro interno durante sincronização',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 })
  }
}