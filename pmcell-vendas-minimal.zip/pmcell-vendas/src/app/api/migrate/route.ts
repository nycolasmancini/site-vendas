import { NextRequest, NextResponse } from 'next/server'
import { execSync } from 'child_process'

export async function POST(request: NextRequest) {
  try {
    console.log('🚀 Executando migration na produção...')
    
    // Executar migration
    const result = execSync('npx prisma migrate deploy', { 
      encoding: 'utf8',
      timeout: 30000 
    })
    
    console.log('✅ Migration executada:', result)
    
    return NextResponse.json({ 
      success: true,
      message: 'Migration executada com sucesso',
      output: result,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Erro na migration:', error)
    
    return NextResponse.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}