import { NextRequest, NextResponse } from 'next/server'
import { syncDatabase } from '@/lib/db-sync'

export async function POST(request: NextRequest) {
  try {
    // Verificar se é ambiente de produção ou se tem autorização
    const isProduction = process.env.NODE_ENV === 'production'
    
    if (isProduction) {
      // Em produção, verificar se há um token de autorização
      const authHeader = request.headers.get('authorization')
      if (authHeader !== `Bearer ${process.env.ADMIN_SYNC_TOKEN}`) {
        return NextResponse.json({ 
          error: 'Não autorizado' 
        }, { status: 401 })
      }
    }

    const result = await syncDatabase()
    
    if (result.success) {
      return NextResponse.json({ 
        message: result.message,
        timestamp: new Date().toISOString()
      })
    } else {
      return NextResponse.json({ 
        error: result.error 
      }, { status: 500 })
    }

  } catch (error) {
    console.error('Erro na rota de sincronização:', error)
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 })
  }
}