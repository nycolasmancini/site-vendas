import { NextRequest, NextResponse } from 'next/server'
import { initializeSchema, checkSchemaStatus, seedBasicCategories } from '@/lib/init-schema'

export async function POST(request: NextRequest) {
  try {
    console.log('🚀 Iniciando inicialização manual do banco de dados...')
    
    // Verificar status atual
    const statusBefore = await checkSchemaStatus()
    console.log('📊 Status antes da inicialização:', statusBefore)
    
    // Executar inicialização
    const initResult = await initializeSchema()
    
    if (!initResult.success) {
      return NextResponse.json({ 
        error: 'Falha na inicialização do schema',
        details: initResult.errors,
        created: initResult.created
      }, { status: 500 })
    }
    
    // Verificar status após inicialização
    const statusAfter = await checkSchemaStatus()
    console.log('📊 Status após inicialização:', statusAfter)
    
    // Se tudo deu certo, tentar criar categorias básicas
    let categoriesSeeded = false
    try {
      categoriesSeeded = await seedBasicCategories()
      console.log('🌱 Categorias básicas criadas:', categoriesSeeded)
    } catch (seedError) {
      console.error('⚠️ Erro ao criar categorias básicas:', seedError)
    }
    
    return NextResponse.json({ 
      success: true,
      message: 'Banco de dados inicializado com sucesso',
      details: {
        tablesCreated: initResult.created,
        statusBefore,
        statusAfter,
        categoriesSeeded,
        schemaInitialized: initResult.success
      },
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Erro na inicialização manual:', error)
    
    return NextResponse.json({ 
      error: 'Erro na inicialização do banco de dados',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}