import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: sessionId } = await params

    if (!sessionId) {
      return NextResponse.json(
        { error: 'SessionId é obrigatório' },
        { status: 400 }
      )
    }

    console.log('📊 Analytics Session Detail: Buscando dados para sessionId:', sessionId)

    // Buscar sessão com todos os dados relacionados
    const session = await prisma.analyticsSession.findUnique({
      where: { sessionId },
      include: {
        categoryVisits: {
          orderBy: { lastVisit: 'desc' }
        },
        productViews: {
          orderBy: { lastView: 'desc' }
        },
        searchHistory: {
          orderBy: { lastSearch: 'desc' }
        },
        cartEvents: {
          orderBy: { timestamp: 'desc' }
        },
        pageViews: {
          orderBy: { timestamp: 'desc' }
        }
      }
    })

    if (!session) {
      return NextResponse.json(
        { error: 'Sessão não encontrada' },
        { status: 404 }
      )
    }

    // Calcular estatísticas da sessão
    const now = Date.now()
    const sessionStart = session.startTime.getTime()
    const lastActivity = session.lastActivity.getTime()
    const timeSinceLastActivity = Math.floor((now - lastActivity) / 1000)
    const totalTimeOnSite = Math.floor((lastActivity - sessionStart) / 1000)

    // Determinar status da sessão
    let sessionStatus = 'abandoned'
    if (timeSinceLastActivity < 300) { // 5 minutos
      sessionStatus = 'active'
    } else if (timeSinceLastActivity < 1800) { // 30 minutos
      sessionStatus = 'idle'
    }

    // Analisar carrinho
    const cartEvents = session.cartEvents
    const addEvents = cartEvents.filter(e => e.type === 'ADD')
    const removeEvents = cartEvents.filter(e => e.type === 'REMOVE')
    const completeEvents = cartEvents.filter(e => e.type === 'COMPLETE')
    const abandonEvents = cartEvents.filter(e => e.type === 'ABANDON')

    // Calcular itens atuais no carrinho
    const cartItems = new Map()
    cartEvents.forEach(event => {
      const productId = event.productId
      const currentQty = cartItems.get(productId) || 0
      
      if (event.type === 'ADD') {
        cartItems.set(productId, currentQty + event.quantity)
      } else if (event.type === 'REMOVE') {
        cartItems.set(productId, Math.max(0, currentQty - event.quantity))
      } else if (event.type === 'UPDATE') {
        cartItems.set(productId, event.quantity)
      } else if (event.type === 'CLEAR') {
        cartItems.clear()
      }
    })

    // Filtrar apenas itens com quantidade > 0
    const currentCartItems = Array.from(cartItems.entries())
      .filter(([_, quantity]) => quantity > 0)
      .map(([productId, quantity]) => {
        const lastEvent = cartEvents
          .filter(e => e.productId === productId)
          .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0]
        
        return {
          productId,
          productName: lastEvent?.productName || 'Produto sem nome',
          quantity,
          unitPrice: lastEvent?.unitPrice || 0,
          totalPrice: lastEvent?.totalPrice || 0
        }
      })

    let cartStatus = 'empty'
    if (completeEvents.length > 0) {
      cartStatus = 'completed'
    } else if (abandonEvents.length > 0) {
      cartStatus = 'abandoned'
    } else if (currentCartItems.length > 0) {
      cartStatus = 'active'
    }

    // Calcular total do carrinho atual
    const cartTotal = currentCartItems.reduce((sum, item) => sum + (item.totalPrice || item.unitPrice * item.quantity), 0)

    // Preparar timeline completa de atividades
    const timeline: Array<{
      type: string
      timestamp: string
      data: any
    }> = []
    
    // Adicionar page views
    session.pageViews.forEach(view => {
      timeline.push({
        type: 'page_view',
        timestamp: view.timestamp.toISOString(),
        data: {
          path: view.path,
          title: view.title,
          duration: view.duration
        }
      })
    })

    // Adicionar category visits
    session.categoryVisits.forEach(visit => {
      timeline.push({
        type: 'category_visit',
        timestamp: visit.lastVisit.toISOString(),
        data: {
          categoryName: visit.categoryName,
          visits: visit.visits,
          hasCartItems: visit.hasCartItems
        }
      })
    })

    // Adicionar product views
    session.productViews.forEach(view => {
      timeline.push({
        type: 'product_view',
        timestamp: view.lastView.toISOString(),
        data: {
          productId: view.productId,
          productName: view.productName,
          categoryName: view.categoryName,
          visits: view.visits,
          addedToCart: view.addedToCart
        }
      })
    })

    // Adicionar searches
    session.searchHistory.forEach(search => {
      timeline.push({
        type: 'search',
        timestamp: search.lastSearch.toISOString(),
        data: {
          term: search.term,
          count: search.count
        }
      })
    })

    // Adicionar cart events
    session.cartEvents.forEach(event => {
      timeline.push({
        type: 'cart_event',
        timestamp: event.timestamp.toISOString(),
        data: {
          type: event.type,
          productId: event.productId,
          productName: event.productName,
          quantity: event.quantity,
          unitPrice: event.unitPrice,
          totalPrice: event.totalPrice
        }
      })
    })

    // Ordenar timeline por timestamp
    timeline.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    const response = {
      success: true,
      session: {
        id: session.id,
        sessionId: session.sessionId,
        whatsapp: session.whatsapp,
        startTime: session.startTime.toISOString(),
        lastActivity: session.lastActivity.toISOString(),
        timeOnSite: totalTimeOnSite,
        whatsappCollectedAt: session.whatsappCollectedAt?.toISOString() || null,
        isActive: session.isActive,
        status: sessionStatus,
        timeSinceLastActivity,
        
        // Estatísticas
        stats: {
          categoriesVisited: session.categoryVisits.length,
          productsViewed: session.productViews.length,
          searchesPerformed: session.searchHistory.length,
          cartEventsCount: session.cartEvents.length,
          pageViewsCount: session.pageViews.length,
          totalTimeOnSite: totalTimeOnSite
        },

        // Carrinho atual
        cart: {
          status: cartStatus,
          items: currentCartItems,
          total: cartTotal,
          itemsCount: currentCartItems.length,
          totalQuantity: currentCartItems.reduce((sum, item) => sum + item.quantity, 0)
        },

        // Dados detalhados
        categoryVisits: session.categoryVisits.map(visit => ({
          id: visit.id,
          categoryId: visit.categoryId,
          categoryName: visit.categoryName,
          visits: visit.visits,
          lastVisit: visit.lastVisit.toISOString(),
          hasCartItems: visit.hasCartItems
        })),
        
        productViews: session.productViews.map(view => ({
          id: view.id,
          productId: view.productId,
          productName: view.productName,
          categoryName: view.categoryName,
          visits: view.visits,
          lastView: view.lastView.toISOString(),
          addedToCart: view.addedToCart
        })),
        
        searchHistory: session.searchHistory.map(search => ({
          id: search.id,
          term: search.term,
          count: search.count,
          lastSearch: search.lastSearch.toISOString()
        })),
        
        cartEvents: session.cartEvents.map(event => ({
          id: event.id,
          type: event.type,
          productId: event.productId,
          productName: event.productName,
          quantity: event.quantity,
          unitPrice: event.unitPrice,
          totalPrice: event.totalPrice,
          timestamp: event.timestamp.toISOString()
        })),
        
        timeline,
        
        createdAt: session.createdAt.toISOString(),
        updatedAt: session.updatedAt.toISOString()
      }
    }

    return NextResponse.json(response)

  } catch (error) {
    console.error('❌ Analytics Session Detail: Erro ao buscar sessão:', error)
    
    return NextResponse.json(
      { 
        error: 'Erro interno do servidor',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      },
      { status: 500 }
    )
  } finally {
    await prisma.$disconnect()
  }
}