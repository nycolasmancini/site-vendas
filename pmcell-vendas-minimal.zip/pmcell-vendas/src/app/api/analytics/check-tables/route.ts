import { NextResponse } from 'next/server'
import { query } from '@/lib/db'

export async function POST() {
  try {
    console.log('🔍 Verificando se tabelas Analytics existem...')
    
    // Verificar se tabelas Analytics existem
    const result = await query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
      ORDER BY table_name
    `)
    
    const existingTables = result.rows.map(row => row.table_name)
    const requiredTables = ['AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent']
    const missingTables = requiredTables.filter(table => !existingTables.includes(table))
    
    const tablesExist = missingTables.length === 0
    
    console.log('📊 Status das tabelas Analytics:', {
      existingTables,
      missingTables,
      tablesExist
    })
    
    return NextResponse.json({
      tablesExist,
      existingTables,
      missingTables,
      canSaveAnalytics: tablesExist
    })
    
  } catch (error) {
    console.error('❌ Erro ao verificar tabelas Analytics:', error)
    
    return NextResponse.json({
      tablesExist: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      canSaveAnalytics: false
    }, { status: 500 })
  }
}

export async function GET() {
  return POST() // Permitir GET também para facilitar testes
}