import { NextResponse } from 'next/server'
import { query } from '@/lib/db'

/**
 * Endpoint GET simples para criar tabelas Analytics em produção
 * Pode ser executado diretamente no browser: https://pmcellvendas.vercel.app/api/analytics/setup
 */
export async function GET() {
  try {
    console.log('🔄 Setup Analytics: Iniciando verificação e criação de tabelas...')
    
    // Verificar se tabelas já existem
    const checkResult = await query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'AnalyticsSession'
    `)
    
    if (checkResult.rows.length > 0) {
      console.log('✅ Setup Analytics: Tabelas já existem!')
      return NextResponse.json({
        success: true,
        message: 'Tabelas Analytics já existem e estão prontas para uso',
        status: 'ready'
      })
    }

    console.log('🔧 Setup Analytics: Criando tabelas...')
    
    // Criar todas as tabelas de uma vez
    await query(`
      -- 1. Criar enum CartEventType
      DO $$ BEGIN
        CREATE TYPE "public"."CartEventType" AS ENUM ('ADD', 'REMOVE', 'UPDATE', 'CLEAR', 'COMPLETE', 'ABANDON');
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'CartEventType enum já existe';
      END $$;

      -- 2. Criar tabela AnalyticsSession
      CREATE TABLE IF NOT EXISTS "public"."AnalyticsSession" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "whatsapp" TEXT,
          "startTime" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "lastActivity" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "timeOnSite" INTEGER NOT NULL DEFAULT 0,
          "whatsappCollectedAt" TIMESTAMP(3),
          "isActive" BOOLEAN NOT NULL DEFAULT true,
          "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "AnalyticsSession_pkey" PRIMARY KEY ("id")
      );

      -- 3. Criar demais tabelas
      CREATE TABLE IF NOT EXISTS "public"."PageView" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "path" TEXT NOT NULL,
          "title" TEXT,
          "duration" INTEGER,
          "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "PageView_pkey" PRIMARY KEY ("id")
      );

      CREATE TABLE IF NOT EXISTS "public"."CategoryVisit" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "categoryId" TEXT NOT NULL,
          "categoryName" TEXT NOT NULL,
          "visits" INTEGER NOT NULL DEFAULT 1,
          "lastVisit" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "hasCartItems" BOOLEAN NOT NULL DEFAULT false,
          "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "CategoryVisit_pkey" PRIMARY KEY ("id")
      );

      CREATE TABLE IF NOT EXISTS "public"."ProductView" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "productId" TEXT NOT NULL,
          "productName" TEXT NOT NULL,
          "categoryName" TEXT,
          "visits" INTEGER NOT NULL DEFAULT 1,
          "lastView" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "addedToCart" BOOLEAN NOT NULL DEFAULT false,
          "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "ProductView_pkey" PRIMARY KEY ("id")
      );

      CREATE TABLE IF NOT EXISTS "public"."SearchHistory" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "term" TEXT NOT NULL,
          "count" INTEGER NOT NULL DEFAULT 1,
          "lastSearch" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "SearchHistory_pkey" PRIMARY KEY ("id")
      );

      CREATE TABLE IF NOT EXISTS "public"."CartEvent" (
          "id" TEXT NOT NULL DEFAULT ('cm' || substr(md5(random()::text), 1, 13)),
          "sessionId" TEXT NOT NULL,
          "type" "public"."CartEventType" NOT NULL,
          "productId" TEXT NOT NULL,
          "productName" TEXT,
          "quantity" INTEGER NOT NULL,
          "unitPrice" DOUBLE PRECISION,
          "totalPrice" DOUBLE PRECISION,
          "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT "CartEvent_pkey" PRIMARY KEY ("id")
      );

      -- 4. Criar índices
      CREATE UNIQUE INDEX IF NOT EXISTS "AnalyticsSession_sessionId_key" ON "public"."AnalyticsSession"("sessionId");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_whatsapp_idx" ON "public"."AnalyticsSession"("whatsapp");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_lastActivity_idx" ON "public"."AnalyticsSession"("lastActivity");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_createdAt_idx" ON "public"."AnalyticsSession"("createdAt");

      CREATE INDEX IF NOT EXISTS "PageView_sessionId_idx" ON "public"."PageView"("sessionId");
      CREATE INDEX IF NOT EXISTS "PageView_timestamp_idx" ON "public"."PageView"("timestamp");

      CREATE UNIQUE INDEX IF NOT EXISTS "CategoryVisit_sessionId_categoryId_key" ON "public"."CategoryVisit"("sessionId", "categoryId");
      CREATE INDEX IF NOT EXISTS "CategoryVisit_sessionId_idx" ON "public"."CategoryVisit"("sessionId");
      CREATE INDEX IF NOT EXISTS "CategoryVisit_timestamp_idx" ON "public"."CategoryVisit"("timestamp");

      CREATE UNIQUE INDEX IF NOT EXISTS "ProductView_sessionId_productId_key" ON "public"."ProductView"("sessionId", "productId");
      CREATE INDEX IF NOT EXISTS "ProductView_sessionId_idx" ON "public"."ProductView"("sessionId");
      CREATE INDEX IF NOT EXISTS "ProductView_productId_idx" ON "public"."ProductView"("productId");
      CREATE INDEX IF NOT EXISTS "ProductView_timestamp_idx" ON "public"."ProductView"("timestamp");

      CREATE UNIQUE INDEX IF NOT EXISTS "SearchHistory_sessionId_term_key" ON "public"."SearchHistory"("sessionId", "term");
      CREATE INDEX IF NOT EXISTS "SearchHistory_sessionId_idx" ON "public"."SearchHistory"("sessionId");
      CREATE INDEX IF NOT EXISTS "SearchHistory_timestamp_idx" ON "public"."SearchHistory"("timestamp");

      CREATE INDEX IF NOT EXISTS "CartEvent_sessionId_idx" ON "public"."CartEvent"("sessionId");
      CREATE INDEX IF NOT EXISTS "CartEvent_type_idx" ON "public"."CartEvent"("type");
      CREATE INDEX IF NOT EXISTS "CartEvent_timestamp_idx" ON "public"."CartEvent"("timestamp");

      -- 5. Criar foreign keys
      DO $$ BEGIN
        ALTER TABLE "public"."PageView" ADD CONSTRAINT "PageView_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'PageView foreign key já existe';
      END $$;

      DO $$ BEGIN
        ALTER TABLE "public"."CategoryVisit" ADD CONSTRAINT "CategoryVisit_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'CategoryVisit foreign key já existe';
      END $$;

      DO $$ BEGIN
        ALTER TABLE "public"."ProductView" ADD CONSTRAINT "ProductView_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'ProductView foreign key já existe';
      END $$;

      DO $$ BEGIN
        ALTER TABLE "public"."SearchHistory" ADD CONSTRAINT "SearchHistory_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'SearchHistory foreign key já existe';
      END $$;

      DO $$ BEGIN
        ALTER TABLE "public"."CartEvent" ADD CONSTRAINT "CartEvent_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
      EXCEPTION
        WHEN duplicate_object THEN 
          RAISE NOTICE 'CartEvent foreign key já existe';
      END $$;
    `)

    console.log('✅ Setup Analytics: Tabelas criadas com sucesso!')
    
    // Verificar se criação foi bem-sucedida
    const verifyResult = await query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
      ORDER BY table_name
    `)
    
    const createdTables = verifyResult.rows.map(row => row.table_name)
    
    return NextResponse.json({
      success: true,
      message: 'Tabelas Analytics criadas e configuradas com sucesso!',
      status: 'created',
      tables: createdTables,
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('❌ Setup Analytics: Erro:', error)
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      status: 'failed'
    }, { status: 500 })
  }
}