import { NextResponse } from 'next/server'
import { query } from '@/lib/db'

export async function GET() {
  try {
    console.log('🔍 Health check do sistema Analytics...')
    
    // Verificar tabelas Analytics
    const tablesResult = await query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
    `)
    
    const existingTables = tablesResult.rows.map(row => row.table_name)
    const requiredTables = ['AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent']
    const missingTables = requiredTables.filter(table => !existingTables.includes(table))
    const analyticsTablesReady = missingTables.length === 0
    
    // Verificar queue local (simular - em produção seria via headers ou session)
    let queuePendingItems = 0
    try {
      // Tentar contar registros pendentes na AnalyticsSession
      if (analyticsTablesReady) {
        const queueResult = await query(`
          SELECT COUNT(*) as count 
          FROM "AnalyticsSession" 
          WHERE "isActive" = true 
          AND "lastActivity" > NOW() - INTERVAL '1 day'
        `)
        queuePendingItems = parseInt(queueResult.rows[0]?.count || '0')
      }
    } catch (error) {
      console.warn('⚠️ Não foi possível contar queue:', error)
    }
    
    const status = {
      analyticsTablesReady,
      canSaveAnalytics: analyticsTablesReady,
      existingTables,
      missingTables,
      queuePendingItems,
      timestamp: new Date().toISOString(),
      databaseConnected: true
    }
    
    console.log('📊 Analytics Health Check:', status)
    
    return NextResponse.json(status)
    
  } catch (error) {
    console.error('❌ Erro no health check Analytics:', error)
    
    return NextResponse.json({
      analyticsTablesReady: false,
      canSaveAnalytics: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      databaseConnected: false,
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}