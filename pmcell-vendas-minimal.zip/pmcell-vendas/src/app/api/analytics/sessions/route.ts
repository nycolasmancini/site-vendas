import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const whatsapp = searchParams.get('whatsapp')
    const status = searchParams.get('status') // 'active', 'abandoned', 'all'
    const dateFrom = searchParams.get('dateFrom')
    const dateTo = searchParams.get('dateTo')

    // Construir filtros
    const where: any = {}
    
    if (whatsapp) {
      where.whatsapp = {
        contains: whatsapp,
        mode: 'insensitive'
      }
    }

    if (dateFrom) {
      where.createdAt = {
        gte: new Date(dateFrom)
      }
    }

    if (dateTo) {
      where.createdAt = {
        ...where.createdAt,
        lte: new Date(dateTo)
      }
    }

    // Filtro por status
    const now = new Date()
    if (status === 'active') {
      const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000)
      where.lastActivity = {
        gte: fiveMinutesAgo
      }
    } else if (status === 'abandoned') {
      const thirtyMinutesAgo = new Date(now.getTime() - 30 * 60 * 1000)
      where.lastActivity = {
        lt: thirtyMinutesAgo
      }
    }

    // Buscar sessões com dados relacionados
    const sessions = await prisma.analyticsSession.findMany({
      where,
      include: {
        categoryVisits: {
          orderBy: { visits: 'desc' }
        },
        productViews: {
          orderBy: { visits: 'desc' },
          take: 10
        },
        searchHistory: {
          orderBy: { count: 'desc' },
          take: 10
        },
        cartEvents: {
          orderBy: { timestamp: 'desc' },
          take: 20
        },
        pageViews: {
          orderBy: { timestamp: 'desc' },
          take: 10
        }
      },
      orderBy: { lastActivity: 'desc' },
      skip: (page - 1) * limit,
      take: limit
    })

    // Contar total para paginação
    const total = await prisma.analyticsSession.count({ where })

    // Processar dados para resposta
    const processedSessions = sessions.map(session => {
      const now = Date.now()
      const lastActivityTime = session.lastActivity.getTime()
      const timeSinceLastActivity = Math.floor((now - lastActivityTime) / 1000)
      
      // Determinar status
      let sessionStatus = 'abandoned'
      if (timeSinceLastActivity < 300) { // 5 minutos
        sessionStatus = 'active'
      } else if (timeSinceLastActivity < 1800) { // 30 minutos
        sessionStatus = 'idle'
      }

      // Calcular se há itens no carrinho
      const hasCartItems = session.cartEvents.some(event => event.type === 'ADD')
      const cartAbandonedEvents = session.cartEvents.filter(event => event.type === 'ABANDON')
      const cartCompletedEvents = session.cartEvents.filter(event => event.type === 'COMPLETE')
      
      let cartStatus = 'empty'
      if (cartCompletedEvents.length > 0) {
        cartStatus = 'completed'
      } else if (cartAbandonedEvents.length > 0) {
        cartStatus = 'abandoned'
      } else if (hasCartItems) {
        cartStatus = 'active'
      }

      return {
        id: session.id,
        sessionId: session.sessionId,
        whatsapp: session.whatsapp,
        startTime: session.startTime.toISOString(),
        lastActivity: session.lastActivity.toISOString(),
        timeOnSite: session.timeOnSite,
        whatsappCollectedAt: session.whatsappCollectedAt?.toISOString() || null,
        isActive: session.isActive,
        status: sessionStatus,
        cartStatus,
        timeSinceLastActivity,
        
        // Estatísticas
        stats: {
          categoriesVisited: session.categoryVisits.length,
          productsViewed: session.productViews.length,
          searchesPerformed: session.searchHistory.length,
          cartEventsCount: session.cartEvents.length,
          pageViewsCount: session.pageViews.length
        },

        // Dados detalhados
        categoryVisits: session.categoryVisits,
        productViews: session.productViews,
        searchHistory: session.searchHistory,
        cartEvents: session.cartEvents,
        pageViews: session.pageViews,

        createdAt: session.createdAt.toISOString(),
        updatedAt: session.updatedAt.toISOString()
      }
    })

    // Estatísticas gerais
    const stats = {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      summary: {
        active: processedSessions.filter(s => s.status === 'active').length,
        idle: processedSessions.filter(s => s.status === 'idle').length,
        abandoned: processedSessions.filter(s => s.status === 'abandoned').length,
        withWhatsApp: processedSessions.filter(s => s.whatsapp).length,
        withCartItems: processedSessions.filter(s => s.cartStatus !== 'empty').length
      }
    }

    return NextResponse.json({
      success: true,
      sessions: processedSessions,
      stats,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Analytics Sessions: Erro ao buscar sessões:', error)
    
    return NextResponse.json(
      { 
        error: 'Erro interno do servidor',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      },
      { status: 500 }
    )
  } finally {
    await prisma.$disconnect()
  }
}