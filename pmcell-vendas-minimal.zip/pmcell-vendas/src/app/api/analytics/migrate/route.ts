import { NextRequest, NextResponse } from 'next/server'
import { migrateAnalyticsTables } from '../../../../../migrate-analytics-production.js'

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Executando migração das tabelas Analytics...')
    
    const result = await migrateAnalyticsTables()
    
    console.log('✅ Migração concluída:', result.message)
    
    return NextResponse.json({
      success: true,
      message: result.message
    })
    
  } catch (error) {
    console.error('❌ Erro na migração:', error)
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Use POST para executar a migração das tabelas Analytics',
    endpoint: '/api/analytics/migrate',
    method: 'POST'
  })
}