import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { uploadImageToCloudinary, validateImage, uploadImageWithFallback } from '@/lib/cloudinary'
import { fileToBuffer, generateUniqueFileName } from '@/lib/image-utils'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Buscar todas as imagens do produto ordenadas
    const images = await prisma.productImage.findMany({
      where: { productId: id },
      orderBy: [
        { isMain: 'desc' },  // Imagem principal primeiro
        { order: 'asc' }     // Depois por ordem
      ]
    })

    return NextResponse.json({ images })
  } catch (error) {
    console.error('Erro ao buscar imagens:', error)
    return NextResponse.json({ error: 'Falha ao buscar imagens' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: productId } = await params
    console.log(`🔄 [IMAGE_UPLOAD] Iniciando upload para produto: ${productId}`)

    // Verificar configuração do Cloudinary
    const cloudinaryConfigured = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)
    console.log(`🔧 [IMAGE_UPLOAD] Cloudinary configurado: ${cloudinaryConfigured}`)

    // Verificar se o produto existe
    console.log(`🔍 [IMAGE_UPLOAD] Buscando produto no banco...`)
    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: { images: true }
    })

    if (!product) {
      console.log(`❌ [IMAGE_UPLOAD] Produto não encontrado: ${productId}`)
      return NextResponse.json({ error: 'Produto não encontrado' }, { status: 404 })
    }

    console.log(`✅ [IMAGE_UPLOAD] Produto encontrado: ${product.name}, imagens atuais: ${product.images.length}`)

    // Verificar limite de 4 imagens
    if (product.images.length >= 4) {
      return NextResponse.json({ 
        error: 'Produto já possui o máximo de 4 imagens' 
      }, { status: 400 })
    }

    console.log(`📤 [IMAGE_UPLOAD] Processando FormData...`)
    const formData = await request.formData()
    const files = formData.getAll('images') as File[]

    console.log(`📋 [IMAGE_UPLOAD] Arquivos recebidos: ${files.length}`)
    files.forEach((file, index) => {
      console.log(`📄 [IMAGE_UPLOAD] Arquivo ${index + 1}: ${file.name} (${file.size} bytes, ${file.type})`)
    })

    if (files.length === 0) {
      console.log(`❌ [IMAGE_UPLOAD] Nenhuma imagem enviada`)
      return NextResponse.json({ error: 'Nenhuma imagem enviada' }, { status: 400 })
    }

    // Verificar se não excederá o limite
    if (product.images.length + files.length > 4) {
      return NextResponse.json({ 
        error: `Máximo 4 imagens por produto. Você pode adicionar apenas ${4 - product.images.length} imagem(ns)` 
      }, { status: 400 })
    }

    const uploadedImages: any[] = []

    // Processar cada imagem
    console.log(`🔄 [IMAGE_UPLOAD] Iniciando processamento de ${files.length} arquivo(s)...`)
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      console.log(`📸 [IMAGE_UPLOAD] Processando imagem ${i + 1}/${files.length}: ${file.name}`)

      // Validar imagem
      console.log(`✔️ [IMAGE_UPLOAD] Validando formato da imagem ${i + 1}...`)
      const validation = validateImage(file)
      if (!validation.valid) {
        console.log(`❌ [IMAGE_UPLOAD] Validação falhou para imagem ${i + 1}: ${validation.error}`)
        return NextResponse.json({ 
          error: `Imagem ${i + 1}: ${validation.error}` 
        }, { status: 400 })
      }

      try {
        // Converter para buffer
        console.log(`🔄 [IMAGE_UPLOAD] Convertendo imagem ${i + 1} para buffer...`)
        const buffer = await fileToBuffer(file)
        const uniqueFileName = generateUniqueFileName(file.name)
        console.log(`📝 [IMAGE_UPLOAD] Nome único gerado: ${uniqueFileName}`)

        // Upload para Cloudinary com fallback
        console.log(`☁️ [IMAGE_UPLOAD] Fazendo upload para Cloudinary...`)
        const cloudinaryResult = await uploadImageWithFallback(buffer, uniqueFileName, {
          folder: 'pmcell/products',
          quality: 'auto',
          format: 'webp'
        })
        console.log(`✅ [IMAGE_UPLOAD] Upload para Cloudinary concluído:`, {
          publicId: cloudinaryResult.public_id,
          url: cloudinaryResult.secure_url,
          size: cloudinaryResult.bytes
        })

        // Determinar ordem e se é principal
        const currentOrder = product.images.length + i
        const isMain = product.images.length === 0 && i === 0 // Primeira imagem é principal se não há outras
        console.log(`📊 [IMAGE_UPLOAD] Ordem da imagem: ${currentOrder}, É principal: ${isMain}`)

        // Salvar no banco de dados
        console.log(`💾 [IMAGE_UPLOAD] Salvando imagem ${i + 1} no banco de dados...`)
        const imageData = {
          productId,
          url: cloudinaryResult.secure_url,
          fileName: file.name,
          order: currentOrder,
          isMain
        }
        console.log(`📄 [IMAGE_UPLOAD] Dados da imagem para salvar:`, imageData)
        
        const image = await prisma.productImage.create({
          data: imageData
        })
        
        console.log(`✅ [IMAGE_UPLOAD] Imagem ${i + 1} salva no banco:`, {
          id: image.id,
          fileName: image.fileName,
          order: image.order,
          isMain: image.isMain
        })

        uploadedImages.push(image)

        console.log(`✅ Imagem ${i + 1} uploaded:`, {
          fileName: file.name,
          publicId: cloudinaryResult.public_id,
          size: cloudinaryResult.bytes,
          isMain
        })

      } catch (uploadError) {
        console.error(`❌ [IMAGE_UPLOAD] Erro no upload da imagem ${i + 1}:`, {
          error: uploadError,
          fileName: file.name,
          fileSize: file.size,
          fileType: file.type,
          cloudinaryConfigured,
          stack: uploadError instanceof Error ? uploadError.stack : undefined
        })
        return NextResponse.json({ 
          error: `Erro no upload da imagem ${i + 1}: ${uploadError instanceof Error ? uploadError.message : 'Erro desconhecido'}` 
        }, { status: 500 })
      }
    }

    console.log(`🎉 [IMAGE_UPLOAD] Processo concluído com sucesso: ${uploadedImages.length} imagem(s) adicionada(s)`)
    return NextResponse.json({ 
      message: `${uploadedImages.length} imagem(ns) adicionada(s) com sucesso`,
      images: uploadedImages
    })

  } catch (error) {
    let errorProductId = 'unknown'
    try {
      const { id } = await params
      errorProductId = id
    } catch (paramError) {
      console.warn('Não foi possível extrair productId dos params')
    }
    
    console.error('❌ [IMAGE_UPLOAD] Erro crítico no endpoint:', {
      error: error,
      stack: error instanceof Error ? error.stack : undefined,
      productId: errorProductId,
      cloudinaryConfig: {
        cloudName: !!process.env.CLOUDINARY_CLOUD_NAME,
        apiKey: !!process.env.CLOUDINARY_API_KEY,
        apiSecret: !!process.env.CLOUDINARY_API_SECRET
      }
    })

    // Determinar tipo de erro para dar feedback específico
    if (error instanceof Error) {
      if (error.message.includes('Cloudinary')) {
        return NextResponse.json({ 
          error: 'Erro no serviço de upload de imagens. Tente novamente em alguns minutos.' 
        }, { status: 503 })
      }
      
      if (error.message.includes('Database') || error.message.includes('Prisma')) {
        return NextResponse.json({ 
          error: 'Erro no banco de dados. Tente novamente.' 
        }, { status: 503 })
      }
      
      if (error.message.includes('FormData')) {
        return NextResponse.json({ 
          error: 'Dados da imagem inválidos. Verifique o arquivo e tente novamente.' 
        }, { status: 400 })
      }
    }
    
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 })
  }
}