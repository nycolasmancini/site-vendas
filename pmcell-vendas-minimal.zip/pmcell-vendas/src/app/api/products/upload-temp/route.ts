import { NextRequest, NextResponse } from 'next/server'
import { uploadImageWithFallback, validateImage } from '@/lib/cloudinary'
import { fileToBuffer, generateUniqueFileName } from '@/lib/image-utils'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const files = formData.getAll('images') as File[]

    console.log(`📤 Upload temporário: recebidos ${files.length} arquivo(s)`)

    // Verificar configuração do Cloudinary e avisar se não estiver configurado
    const cloudinaryConfigured = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)
    if (!cloudinaryConfigured) {
      console.warn('⚠️ Cloudinary não configurado, usando fallback base64')
    }

    if (files.length === 0) {
      return NextResponse.json({ error: 'Nenhuma imagem enviada' }, { status: 400 })
    }

    if (files.length > 4) {
      return NextResponse.json({ 
        error: 'Máximo 4 imagens por produto' 
      }, { status: 400 })
    }

    const uploadedImages: any[] = []

    // Processar cada imagem
    for (let i = 0; i < files.length; i++) {
      const file = files[i]

      // Validar imagem
      const validation = validateImage(file)
      if (!validation.valid) {
        return NextResponse.json({ 
          error: `Imagem ${i + 1}: ${validation.error}` 
        }, { status: 400 })
      }

      try {
        // Converter para buffer
        const buffer = await fileToBuffer(file)
        const uniqueFileName = generateUniqueFileName(file.name)

        console.log(`📋 Processando imagem ${i + 1}:`, {
          fileName: file.name,
          size: file.size,
          type: file.type,
          uniqueFileName
        })

        // Upload para Cloudinary com fallback automático
        const cloudinaryResult = await uploadImageWithFallback(buffer, uniqueFileName, {
          folder: 'pmcell/temp',
          quality: 'auto',
          format: 'webp'
        })

        // Validar URLs antes de salvar
        const validateUrl = (url: string) => {
          // Verificar se URL não tem dupla extensão
          const hasDoubleExtension = url.match(/\.(webp|jpg|jpeg|png)\.\w+$/i)
          if (hasDoubleExtension) {
            console.warn('⚠️ URL com dupla extensão detectada:', url)
            // Remover a extensão duplicada
            return url.replace(/\.(webp|jpg|jpeg|png)(\.\w+)$/i, '$2')
          }
          return url
        }

        // Criar objeto de imagem temporária
        const tempImage = {
          id: `temp_${Date.now()}_${i}`,
          url: validateUrl(cloudinaryResult.secure_url),
          fileName: file.name,
          order: i,
          isMain: i === 0,
          thumbnailUrl: validateUrl(cloudinaryResult.thumbnailUrl),
          normalUrl: validateUrl(cloudinaryResult.normalUrl),
          cloudinaryPublicId: cloudinaryResult.public_id,
          width: cloudinaryResult.width,
          height: cloudinaryResult.height,
          fileSize: cloudinaryResult.bytes,
          isTemporary: true
        }

        uploadedImages.push(tempImage)

        console.log(`✅ Imagem temporária ${i + 1} uploaded:`, {
          fileName: file.name,
          publicId: cloudinaryResult.public_id,
          size: cloudinaryResult.bytes,
          isMain: i === 0
        })

      } catch (uploadError) {
        console.error(`❌ Erro no upload da imagem ${i + 1}:`, {
          error: uploadError,
          fileName: file.name,
          size: file.size,
          type: file.type,
          cloudinaryConfig: {
            cloudName: !!process.env.CLOUDINARY_CLOUD_NAME,
            apiKey: !!process.env.CLOUDINARY_API_KEY,
            apiSecret: !!process.env.CLOUDINARY_API_SECRET
          }
        })
        return NextResponse.json({ 
          error: `Erro no upload da imagem ${i + 1}: ${uploadError instanceof Error ? uploadError.message : 'Erro desconhecido'}` 
        }, { status: 500 })
      }
    }

    return NextResponse.json({ 
      message: `${uploadedImages.length} imagem(ns) temporária(s) carregada(s) com sucesso`,
      images: uploadedImages
    })

  } catch (error) {
    console.error('Erro no endpoint de upload temporário:', error)
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 })
  }
}