import { NextRequest, NextResponse } from 'next/server'
import { productsCache } from '@/lib/cache'
import { revalidatePath } from 'next/cache'

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Webhook de sincronização de produtos acionado')
    
    // Limpar todos os caches relacionados a produtos
    productsCache.clear()
    
    // Revalidar páginas principais
    revalidatePath('/')
    revalidatePath('/admin/produtos')
    
    console.log('✅ Cache limpo e páginas revalidadas')
    
    return NextResponse.json({
      success: true,
      message: 'Cache limpo e sincronização realizada',
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('❌ Erro no webhook de sincronização:', error)
    return NextResponse.json({
      success: false,
      error: 'Erro interno no webhook'
    }, { status: 500 })
  }
}

export async function GET() {
  try {
    console.log('🔍 Status do cache de produtos')
    
    const stats = productsCache.getStats()
    
    return NextResponse.json({
      cacheStats: stats,
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('❌ Erro ao obter status do cache:', error)
    return NextResponse.json({
      error: 'Erro ao obter status'
    }, { status: 500 })
  }
}