import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Executando sincronização forçada do banco...')
    
    // Testar conexão
    await prisma.$connect()
    console.log('✅ Conectado ao banco')
    
    // Verificar se tabelas existem - se não existir, vai dar erro P2021
    try {
      const categoryCount = await prisma.category.count()
      console.log(`📊 Categorias encontradas: ${categoryCount}`)
      
      const productCount = await prisma.product.count()
      console.log(`📊 Produtos encontrados: ${productCount}`)
      
      return NextResponse.json({ 
        status: 'success',
        message: 'Banco sincronizado e funcionando',
        counts: {
          categories: categoryCount,
          products: productCount
        },
        timestamp: new Date().toISOString()
      })
      
    } catch (schemaError) {
      console.error('❌ Erro de schema:', schemaError)
      
      // Se for erro P2021, tentar forçar push do schema
      if (schemaError instanceof Error && schemaError.message?.includes('P2021')) {
        console.log('🔧 Tabelas não existem, tentando criar...')
        
        // Nota: Em produção não conseguimos executar prisma db push
        // Mas podemos retornar informações úteis
        return NextResponse.json({ 
          status: 'schema_error',
          error: 'Tabelas não existem no banco de dados',
          solution: 'Execute "npx prisma db push" no ambiente local e faça redeploy',
          timestamp: new Date().toISOString()
        }, { status: 500 })
      }
      
      throw schemaError
    }
    
  } catch (error) {
    console.error('❌ Erro na sincronização forçada:', error)
    
    return NextResponse.json({ 
      status: 'error',
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      timestamp: new Date().toISOString()
    }, { status: 500 })
  } finally {
    await prisma.$disconnect()
  }
}