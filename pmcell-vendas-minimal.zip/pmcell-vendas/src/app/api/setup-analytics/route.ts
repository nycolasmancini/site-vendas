import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Setup Analytics: Verificando e criando tabelas de analytics...')

    // Verificar se as tabelas já existem
    const existingTables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
    `

    console.log('📊 Setup Analytics: Tabelas existentes:', existingTables)

    if (Array.isArray(existingTables) && existingTables.length >= 6) {
      return NextResponse.json({
        success: true,
        message: 'Tabelas de analytics já existem',
        tables: existingTables,
        alreadyExists: true
      })
    }

    // Criar enum se não existir
    await prisma.$executeRaw`
      DO $$ BEGIN
        CREATE TYPE "CartEventType" AS ENUM ('ADD', 'REMOVE', 'UPDATE', 'CLEAR', 'COMPLETE', 'ABANDON');
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$;
    `

    // Criar tabela AnalyticsSession se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "AnalyticsSession" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "whatsapp" TEXT,
        "startTime" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "lastActivity" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "timeOnSite" INTEGER NOT NULL DEFAULT 0,
        "whatsappCollectedAt" TIMESTAMP(3),
        "isActive" BOOLEAN NOT NULL DEFAULT true,
        "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" TIMESTAMP(3) NOT NULL,
        CONSTRAINT "AnalyticsSession_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar índices para AnalyticsSession
    await prisma.$executeRaw`
      CREATE UNIQUE INDEX IF NOT EXISTS "AnalyticsSession_sessionId_key" ON "AnalyticsSession"("sessionId");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_whatsapp_idx" ON "AnalyticsSession"("whatsapp");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_lastActivity_idx" ON "AnalyticsSession"("lastActivity");
      CREATE INDEX IF NOT EXISTS "AnalyticsSession_createdAt_idx" ON "AnalyticsSession"("createdAt");
    `

    // Criar tabela PageView se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "PageView" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "path" TEXT NOT NULL,
        "title" TEXT,
        "duration" INTEGER,
        "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "PageView_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar tabela CategoryVisit se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "CategoryVisit" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "categoryId" TEXT NOT NULL,
        "categoryName" TEXT NOT NULL,
        "visits" INTEGER NOT NULL DEFAULT 1,
        "lastVisit" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "hasCartItems" BOOLEAN NOT NULL DEFAULT false,
        "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "CategoryVisit_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar tabela ProductView se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "ProductView" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "productId" TEXT NOT NULL,
        "productName" TEXT NOT NULL,
        "categoryName" TEXT,
        "visits" INTEGER NOT NULL DEFAULT 1,
        "lastView" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "addedToCart" BOOLEAN NOT NULL DEFAULT false,
        "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "ProductView_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar tabela SearchHistory se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "SearchHistory" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "term" TEXT NOT NULL,
        "count" INTEGER NOT NULL DEFAULT 1,
        "lastSearch" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "SearchHistory_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar tabela CartEvent se não existir
    await prisma.$executeRaw`
      CREATE TABLE IF NOT EXISTS "CartEvent" (
        "id" TEXT NOT NULL,
        "sessionId" TEXT NOT NULL,
        "type" "CartEventType" NOT NULL,
        "productId" TEXT NOT NULL,
        "productName" TEXT,
        "quantity" INTEGER NOT NULL,
        "unitPrice" DOUBLE PRECISION,
        "totalPrice" DOUBLE PRECISION,
        "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "CartEvent_pkey" PRIMARY KEY ("id")
      );
    `

    // Criar índices restantes
    await prisma.$executeRaw`
      CREATE INDEX IF NOT EXISTS "PageView_sessionId_idx" ON "PageView"("sessionId");
      CREATE INDEX IF NOT EXISTS "CategoryVisit_sessionId_idx" ON "CategoryVisit"("sessionId");
      CREATE UNIQUE INDEX IF NOT EXISTS "CategoryVisit_sessionId_categoryId_key" ON "CategoryVisit"("sessionId", "categoryId");
      CREATE INDEX IF NOT EXISTS "ProductView_sessionId_idx" ON "ProductView"("sessionId");
      CREATE UNIQUE INDEX IF NOT EXISTS "ProductView_sessionId_productId_key" ON "ProductView"("sessionId", "productId");
      CREATE INDEX IF NOT EXISTS "SearchHistory_sessionId_idx" ON "SearchHistory"("sessionId");
      CREATE UNIQUE INDEX IF NOT EXISTS "SearchHistory_sessionId_term_key" ON "SearchHistory"("sessionId", "term");
      CREATE INDEX IF NOT EXISTS "CartEvent_sessionId_idx" ON "CartEvent"("sessionId");
    `

    console.log('✅ Setup Analytics: Tabelas de analytics criadas com sucesso')

    // Verificar novamente
    const finalTables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
      ORDER BY table_name;
    `

    return NextResponse.json({
      success: true,
      message: 'Tabelas de analytics configuradas com sucesso',
      tables: finalTables,
      created: true,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Setup Analytics: Erro ao configurar tabelas:', error)
    return NextResponse.json(
      { 
        success: false,
        error: 'Erro ao configurar tabelas de analytics',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    // Verificar status das tabelas
    const tables = await prisma.$queryRaw`
      SELECT table_name, 
             (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name AND table_schema = 'public') as column_count
      FROM information_schema.tables t
      WHERE t.table_schema = 'public' 
      AND t.table_name IN ('AnalyticsSession', 'PageView', 'CategoryVisit', 'ProductView', 'SearchHistory', 'CartEvent')
      ORDER BY t.table_name;
    `

    return NextResponse.json({
      success: true,
      message: 'Status das tabelas de analytics',
      tables: tables,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('❌ Setup Analytics: Erro ao verificar tabelas:', error)
    return NextResponse.json(
      { 
        success: false,
        error: 'Erro ao verificar tabelas de analytics',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      },
      { status: 500 }
    )
  }
}