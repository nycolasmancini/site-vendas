import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const checks = {
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'unknown',
      database: false,
      cloudinary: false,
      details: {
        prisma: 'unknown',
        cloudinaryConfig: {
          cloudName: !!process.env.CLOUDINARY_CLOUD_NAME,
          apiKey: !!process.env.CLOUDINARY_API_KEY,
          apiSecret: !!process.env.CLOUDINARY_API_SECRET
        }
      }
    }

    // Testar conexão com banco de dados
    try {
      await prisma.$queryRaw`SELECT 1 as test`
      checks.database = true
      checks.details.prisma = 'connected'
    } catch (dbError) {
      console.error('❌ Erro na conexão com banco:', dbError)
      checks.details.prisma = 'error'
    }

    // Verificar configuração do Cloudinary
    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
      checks.cloudinary = true
    }

    const allHealthy = checks.database && checks.cloudinary
    const status = allHealthy ? 200 : 503

    return NextResponse.json({
      status: allHealthy ? 'healthy' : 'degraded',
      ...checks
    }, { status })

  } catch (error) {
    console.error('❌ Erro no health check:', error)
    return NextResponse.json({
      status: 'error',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 })
  }
}