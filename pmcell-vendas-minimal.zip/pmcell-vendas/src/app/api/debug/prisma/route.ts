import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    console.log('🔍 Testando conexão com Prisma...')
    
    // Testar conexão básica
    await prisma.$connect()
    console.log('✅ Prisma conectado')
    
    // Testar se as tabelas existem
    const tests = {
      categories: await prisma.category.count(),
      products: await prisma.product.count(),
      images: await prisma.productImage.count()
    }
    
    console.log('📊 Contagem de registros:', tests)
    
    // Verificar variáveis de ambiente
    const envCheck = {
      DATABASE_URL: !!process.env.DATABASE_URL,
      DIRECT_URL: !!process.env.DIRECT_URL,
      CLOUDINARY_CLOUD_NAME: !!process.env.CLOUDINARY_CLOUD_NAME,
      CLOUDINARY_API_KEY: !!process.env.CLOUDINARY_API_KEY,
      CLOUDINARY_API_SECRET: !!process.env.CLOUDINARY_API_SECRET
    }
    
    return NextResponse.json({ 
      status: 'ok',
      timestamp: new Date().toISOString(),
      database: tests,
      environment: envCheck
    })

  } catch (error) {
    console.error('❌ Erro no debug Prisma:', error)
    
    return NextResponse.json({ 
      status: 'error',
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}