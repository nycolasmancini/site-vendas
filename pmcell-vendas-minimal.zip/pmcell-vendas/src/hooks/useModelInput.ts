import { useState, useCallback, useRef, useEffect } from 'react'

interface UseModelInputProps {
  modelId: string
  initialQuantity: number
  onQuantityChange: (modelId: string, quantity: number) => void
}

export const useModelInput = ({ modelId, initialQuantity, onQuantityChange }: UseModelInputProps) => {
  const [localValue, setLocalValue] = useState<string>('')
  const [isActive, setIsActive] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const lastSyncedQuantity = useRef<number>(initialQuantity)

  // Atualizar valor local apenas se a quantidade do carrinho mudou externamente
  // (não durante digitação ativa) - MOVIDO PARA useEffect
  useEffect(() => {
    if (!isActive && initialQuantity !== lastSyncedQuantity.current) {
      lastSyncedQuantity.current = initialQuantity
    }
  }, [isActive, initialQuantity])

  // Função para obter valor de exibição
  const getDisplayValue = useCallback((): string => {
    if (isActive && localValue !== '') {
      return localValue
    }
    return initialQuantity.toString()
  }, [isActive, localValue, initialQuantity])

  // Função para lidar com mudanças no input
  const handleInputChange = useCallback((value: string) => {
    // Validar entrada
    if (value !== '' && (isNaN(Number(value)) || Number(value) < 0)) {
      return
    }
    
    setLocalValue(value)
    setIsActive(true)
  }, [])

  // Função para aplicar valor ao carrinho
  const applyValue = useCallback(() => {
    if (isActive) {
      const numValue = parseInt(localValue) || 0
      onQuantityChange(modelId, numValue)
      setLocalValue('')
      setIsActive(false)
      lastSyncedQuantity.current = numValue
    }
  }, [isActive, localValue, modelId, onQuantityChange])

  // Handlers de eventos
  const handleFocus = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
    e.target.select()
    setIsActive(true)
  }, [])

  const handleBlur = useCallback(() => {
    applyValue()
  }, [applyValue])

  const handleKeyPress = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      applyValue()
      inputRef.current?.blur()
    }
  }, [applyValue])

  return {
    inputRef,
    displayValue: getDisplayValue(),
    isActive,
    handleInputChange,
    handleFocus,
    handleBlur,
    handleKeyPress
  }
}