/**
 * Hook para gestão de produtos com cache local para prevenir "piscar"
 * 
 * Resolve o problema de produtos desaparecendo temporariamente ao:
 * 1. Usar cache local para estado inicial
 * 2. Diferenciar "carregando" de "vazio"
 * 3. Implementar refresh otimizado
 */

import { useState, useEffect, useCallback, useMemo } from 'react'
import { throttle } from '@/utils/debounce'

interface Product {
  id: string
  name: string
  updated_at?: string
  stock?: number
}

interface ProductsState {
  products: Product[]
  loading: boolean
  error: string | null
  hasCache: boolean
}

const CACHE_KEY = 'pmcell-products-cache'
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutos

interface CacheData {
  products: Product[]
  timestamp: number
  categoryId?: string
  searchTerm?: string
}

export function useProductsWithCache(categoryId?: string, searchTerm?: string) {
  const [state, setState] = useState<ProductsState>({
    products: [],
    loading: true, // Sempre inicia carregando
    error: null,
    hasCache: false
  })
  
  const [isUserInteracting, setIsUserInteracting] = useState(false)
  const [lastActivity, setLastActivity] = useState(Date.now())

  // Carregar do cache local no mount
  useEffect(() => {
    try {
      const cached = localStorage.getItem(CACHE_KEY)
      if (cached) {
        const cacheData: CacheData = JSON.parse(cached)
        const isValid = Date.now() - cacheData.timestamp < CACHE_DURATION
        
        // Se cache válido e para mesma busca/categoria
        if (isValid && 
            cacheData.categoryId === categoryId && 
            cacheData.searchTerm === searchTerm) {
          console.log('🚀 Usando cache local para estado inicial')
          setState(prev => ({
            ...prev,
            products: cacheData.products,
            hasCache: true,
            loading: false // Cache permite carregar sem loading
          }))
          return
        }
      }
    } catch (error) {
      console.warn('⚠️ Erro ao carregar cache local:', error)
    }
    
    // Se não há cache válido, manter loading: true
    setState(prev => ({ ...prev, hasCache: false }))
  }, [categoryId, searchTerm])

  // Detectar atividade do usuário
  useEffect(() => {
    const handleUserActivity = () => {
      setLastActivity(Date.now())
      setIsUserInteracting(true)
      
      setTimeout(() => setIsUserInteracting(false), 5000)
    }

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart']
    events.forEach(event => {
      document.addEventListener(event, handleUserActivity, { passive: true })
    })

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handleUserActivity)
      })
    }
  }, [])

  // Fingerprint para comparação otimizada
  const productsFingerprint = useMemo(() => {
    return state.products.map(p => ({ 
      id: p.id, 
      updated_at: p.updated_at, 
      stock: p.stock 
    }))
  }, [state.products])

  const loadProducts = useCallback(async (refresh = false, silent = false) => {
    if (!silent && !state.hasCache) {
      setState(prev => ({ ...prev, loading: true, error: null }))
    }

    const params = new URLSearchParams()
    
    if (refresh) {
      params.append('refresh', 'true')
      params.append('t', Date.now().toString())
    }
    
    if (searchTerm) {
      params.append('search', searchTerm)
    } else if (categoryId) {
      params.append('categoryId', categoryId)
    }

    try {
      const response = await fetch(`/api/products?${params}`, {
        cache: 'no-store',
        headers: { 'Cache-Control': 'no-cache' }
      })
      
      const data = await response.json()
      const newProducts = data.products || []
      
      // Se refresh silencioso, comparar antes de atualizar
      if (silent && refresh) {
        const newFingerprint = newProducts.map((p: any) => ({ 
          id: p.id, 
          updated_at: p.updated_at, 
          stock: p.stock 
        }))
        
        const currentJson = JSON.stringify(productsFingerprint)
        const newJson = JSON.stringify(newFingerprint)
        
        if (currentJson !== newJson) {
          setState(prev => ({ ...prev, products: newProducts }))
          console.log('🔄 Produtos atualizados silenciosamente:', {
            antes: productsFingerprint.length,
            depois: newFingerprint.length
          })
        }
      } else {
        setState(prev => ({ 
          ...prev, 
          products: newProducts, 
          loading: false,
          error: null 
        }))
        
        // Salvar no cache
        try {
          const cacheData: CacheData = {
            products: newProducts,
            timestamp: Date.now(),
            categoryId,
            searchTerm
          }
          localStorage.setItem(CACHE_KEY, JSON.stringify(cacheData))
          console.log('💾 Produtos salvos no cache local')
        } catch (cacheError) {
          console.warn('⚠️ Erro ao salvar cache:', cacheError)
        }
      }
      
    } catch (error) {
      console.error('❌ Erro ao carregar produtos:', error)
      if (!silent) {
        setState(prev => ({ 
          ...prev, 
          loading: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido'
        }))
      }
    }
  }, [categoryId, searchTerm, productsFingerprint, state.hasCache])

  // Auto-refresh com throttle
  const throttledRefresh = useCallback(
    throttle(() => {
      if (!isUserInteracting) {
        console.log('🔄 Auto-refresh produtos (throttled)')
        loadProducts(true, true)
      } else {
        console.log('⏸️ Auto-refresh pausado - usuário ativo')
      }
    }, 10000),
    [isUserInteracting, loadProducts]
  )

  // Carregar produtos quando dependências mudam
  useEffect(() => {
    // Se já temos cache, não mostrar loading
    if (!state.hasCache) {
      loadProducts()
    } else {
      // Com cache, fazer refresh silencioso
      loadProducts(true, true)
    }
  }, [categoryId, searchTerm, loadProducts, state.hasCache])

  // Auto-refresh timer
  useEffect(() => {
    const timer = setInterval(throttledRefresh, 30000) // 30 segundos
    return () => clearInterval(timer)
  }, [throttledRefresh])

  return {
    products: state.products,
    loading: state.loading,
    error: state.error,
    hasCache: state.hasCache,
    refresh: () => loadProducts(true, false),
    refreshSilent: () => loadProducts(true, true)
  }
}