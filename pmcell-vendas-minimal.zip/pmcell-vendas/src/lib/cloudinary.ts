import { v2 as cloudinary } from 'cloudinary'

// Configurar Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

export interface CloudinaryUploadResult {
  public_id: string
  secure_url: string
  width: number
  height: number
  format: string
  bytes: number
  thumbnailUrl: string
  normalUrl: string
}

export interface ImageUploadOptions {
  folder?: string
  quality?: 'auto' | number
  format?: 'auto' | 'webp' | 'png'
  transformation?: any[]
}

/**
 * Upload de imagem para Cloudinary com otimizações
 */
export async function uploadImageToCloudinary(
  imageBuffer: Buffer,
  fileName: string,
  options: ImageUploadOptions = {}
): Promise<CloudinaryUploadResult> {
  try {
    // Verificar configuração do Cloudinary
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      throw new Error('Configuração do Cloudinary não encontrada. Verifique as variáveis de ambiente.')
    }

    const {
      folder = 'pmcell/products',
      quality = 'auto',
      format = 'webp'
    } = options

    console.log(`📤 Iniciando upload para Cloudinary:`, {
      fileName,
      folder,
      bufferSize: imageBuffer.length,
      cloudName: process.env.CLOUDINARY_CLOUD_NAME
    })

    // Limpar fileName para evitar extensões duplicadas
    const cleanFileName = fileName.replace(/\.(webp|jpg|jpeg|png)$/, '')
    
    // Upload da imagem original com transformações
    const result = await new Promise<any>((resolve, reject) => {
      const uploadStream = cloudinary.uploader.upload_stream(
        {
          folder,
          public_id: cleanFileName, // Usar fileName limpo sem extensão
          format,
          quality,
          fetch_format: 'auto',
          // Gerar versões automáticas
          eager: [
            { width: 150, height: 150, crop: 'fill', format: 'webp', quality: 70, fetch_format: 'auto' }, // Thumbnail
            { width: 500, height: 500, crop: 'fill', format: 'webp', quality: 80, fetch_format: 'auto' }  // Normal
          ],
          // Tags para organização
          tags: ['product', 'ecommerce'],
          // Timeout para evitar uploads infinitos
          timeout: 60000
        },
        (error, result) => {
          if (error) {
            console.error('❌ Erro no Cloudinary:', error)
            reject(error)
          } else {
            console.log('✅ Upload Cloudinary concluído:', result?.public_id)
            resolve(result)
          }
        }
      )
      
      uploadStream.end(imageBuffer)
    })

    // Gerar URLs das versões sem parâmetros problemáticos
    const thumbnailUrl = cloudinary.url(result.public_id, {
      width: 150,
      height: 150,
      crop: 'fill',
      format: 'webp',
      quality: 70,
      fetch_format: 'auto',
      secure: true
    }).split('?')[0] // Remover qualquer parâmetro de query

    const normalUrl = cloudinary.url(result.public_id, {
      width: 500,
      height: 500,
      crop: 'fill',
      format: 'webp',
      quality: 80,
      fetch_format: 'auto',
      secure: true
    }).split('?')[0] // Remover qualquer parâmetro de query

    return {
      public_id: result.public_id,
      secure_url: result.secure_url,
      width: result.width,
      height: result.height,
      format: result.format,
      bytes: result.bytes,
      thumbnailUrl,
      normalUrl
    }
  } catch (error) {
    console.error('Erro no upload para Cloudinary:', error)
    throw new Error('Falha no upload da imagem')
  }
}

/**
 * Excluir imagem do Cloudinary
 */
export async function deleteImageFromCloudinary(publicId: string): Promise<boolean> {
  try {
    const result = await cloudinary.uploader.destroy(publicId)
    return result.result === 'ok'
  } catch (error) {
    console.error('Erro ao excluir imagem do Cloudinary:', error)
    return false
  }
}

/**
 * Gerar URL otimizada para imagem
 */
export function getOptimizedImageUrl(
  publicId: string,
  size: 'thumbnail' | 'normal' | 'full' = 'normal'
): string {
  const transformations = {
    thumbnail: { width: 150, height: 150, crop: 'fill', quality: 70 },
    normal: { width: 500, height: 500, crop: 'fill', quality: 80 },
    full: { width: 1200, height: 1200, crop: 'limit', quality: 90 }
  }

  return cloudinary.url(publicId, {
    ...transformations[size],
    format: 'webp',
    fetch_format: 'auto',
    secure: true
  }).split('?')[0] // Remover qualquer parâmetro de query
}

/**
 * Validar se imagem é válida
 */
export function validateImage(file: File): { valid: boolean; error?: string } {
  // Verificar formato
  const allowedTypes = ['image/webp', 'image/png', 'image/jpeg']
  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Formato não suportado. Use WebP, PNG ou JPEG.' }
  }

  // Verificar tamanho (5MB máximo)
  if (file.size > 5 * 1024 * 1024) {
    return { valid: false, error: 'Imagem muito grande. Máximo 5MB.' }
  }

  return { valid: true }
}

/**
 * Fallback para upload quando Cloudinary não está configurado
 */
export function createFallbackImageResult(
  imageBuffer: Buffer,
  fileName: string
): CloudinaryUploadResult {
  const base64 = `data:image/jpeg;base64,${imageBuffer.toString('base64')}`
  const fallbackId = `fallback_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
  
  return {
    public_id: fallbackId,
    secure_url: base64,
    width: 500, // Valores padrão
    height: 500,
    format: 'jpeg',
    bytes: imageBuffer.length,
    thumbnailUrl: base64,
    normalUrl: base64
  }
}

/**
 * Upload com fallback automático
 */
export async function uploadImageWithFallback(
  imageBuffer: Buffer,
  fileName: string,
  options: ImageUploadOptions = {}
): Promise<CloudinaryUploadResult> {
  try {
    // Tentar upload no Cloudinary primeiro
    return await uploadImageToCloudinary(imageBuffer, fileName, options)
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido'
    console.warn('⚠️ Cloudinary falhou, usando fallback base64:', errorMessage)
    return createFallbackImageResult(imageBuffer, fileName)
  }
}

export default cloudinary