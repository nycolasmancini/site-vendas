import { execSync } from 'child_process'

export async function syncDatabase() {
  try {
    console.log('🔄 Iniciando sincronização do banco de dados...')
    
    // Gerar client Prisma
    console.log('📦 Gerando Prisma client...')
    execSync('npx prisma generate', { stdio: 'inherit' })
    
    // Sincronizar schema com banco
    console.log('🗄️ Sincronizando schema com banco de dados...')
    execSync('npx prisma db push --accept-data-loss', { stdio: 'inherit' })
    
    console.log('✅ Sincronização concluída com sucesso!')
    return { success: true, message: 'Banco sincronizado com sucesso' }
    
  } catch (error) {
    console.error('❌ Erro na sincronização:', error)
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro desconhecido' 
    }
  }
}