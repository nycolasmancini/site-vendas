import { query } from './db'

export interface SchemaCheck {
  exists: boolean
  table: string
  error?: string
}

/**
 * Verificar se uma tabela existe
 */
async function checkTableExists(tableName: string): Promise<boolean> {
  try {
    const result = await query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = $1
      )
    `, [tableName])
    
    return result?.rows?.[0]?.exists || false
  } catch (error) {
    console.error(`❌ Erro ao verificar tabela ${tableName}:`, error)
    return false
  }
}

/**
 * Verificar status de todas as tabelas principais
 */
export async function checkSchemaStatus(): Promise<SchemaCheck[]> {
  const tables = ['User', 'Admin', 'Category', 'Product', 'ProductImage', 'Brand', 'Model']
  const checks: SchemaCheck[] = []
  
  for (const table of tables) {
    try {
      const exists = await checkTableExists(table)
      checks.push({ exists, table })
    } catch (error) {
      checks.push({ 
        exists: false, 
        table, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      })
    }
  }
  
  return checks
}

/**
 * Criar tabela Category
 */
async function createCategoryTable(): Promise<boolean> {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS "Category" (
        "id" TEXT NOT NULL,
        "name" TEXT NOT NULL,
        "slug" TEXT NOT NULL,
        "icon" TEXT,
        "order" INTEGER NOT NULL DEFAULT 0,
        "isActive" BOOLEAN NOT NULL DEFAULT true,
        "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "Category_pkey" PRIMARY KEY ("id")
      )
    `)
    
    await query(`CREATE UNIQUE INDEX IF NOT EXISTS "Category_slug_key" ON "Category"("slug")`)
    
    console.log('✅ Tabela Category criada')
    return true
  } catch (error) {
    console.error('❌ Erro ao criar tabela Category:', error)
    return false
  }
}

/**
 * Criar tabela Product
 */
async function createProductTable(): Promise<boolean> {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS "Product" (
        "id" TEXT NOT NULL,
        "name" TEXT NOT NULL,
        "subname" TEXT,
        "description" TEXT,
        "brand" TEXT,
        "categoryId" TEXT NOT NULL,
        "isModalProduct" BOOLEAN NOT NULL DEFAULT false,
        "quickAddIncrement" INTEGER,
        "price" DOUBLE PRECISION NOT NULL,
        "specialPrice" DOUBLE PRECISION,
        "specialQuantity" INTEGER,
        "superWholesalePrice" DOUBLE PRECISION,
        "superWholesaleQuantity" INTEGER,
        "cost" DOUBLE PRECISION,
        "boxQuantity" INTEGER,
        "isActive" BOOLEAN NOT NULL DEFAULT true,
        "featured" BOOLEAN NOT NULL DEFAULT false,
        "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
      )
    `)
    
    await query(`
      ALTER TABLE "Product" 
      ADD CONSTRAINT "Product_categoryId_fkey" 
      FOREIGN KEY ("categoryId") REFERENCES "Category"("id") 
      ON DELETE RESTRICT ON UPDATE CASCADE
    `)
    
    console.log('✅ Tabela Product criada')
    return true
  } catch (error) {
    console.error('❌ Erro ao criar tabela Product:', error)
    return false
  }
}

/**
 * Criar tabela ProductImage
 */
async function createProductImageTable(): Promise<boolean> {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS "ProductImage" (
        "id" TEXT NOT NULL,
        "productId" TEXT NOT NULL,
        "url" TEXT NOT NULL,
        "fileName" TEXT,
        "order" INTEGER NOT NULL DEFAULT 0,
        "isMain" BOOLEAN NOT NULL DEFAULT false,
        "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "cloudinaryPublicId" TEXT,
        "fileSize" INTEGER,
        "height" INTEGER,
        "lastViewedAt" TIMESTAMP(3),
        "normalUrl" TEXT,
        "thumbnailUrl" TEXT,
        "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "viewCount" INTEGER NOT NULL DEFAULT 0,
        "width" INTEGER,
        CONSTRAINT "ProductImage_pkey" PRIMARY KEY ("id")
      )
    `)
    
    await query(`
      ALTER TABLE "ProductImage" 
      ADD CONSTRAINT "ProductImage_productId_fkey" 
      FOREIGN KEY ("productId") REFERENCES "Product"("id") 
      ON DELETE CASCADE ON UPDATE CASCADE
    `)
    
    console.log('✅ Tabela ProductImage criada')
    return true
  } catch (error) {
    console.error('❌ Erro ao criar tabela ProductImage:', error)
    return false
  }
}

/**
 * Inicializar schema completo
 */
export async function initializeSchema(): Promise<{ success: boolean; created: string[]; errors: string[] }> {
  const created: string[] = []
  const errors: string[] = []
  
  console.log('🚀 Iniciando inicialização do schema...')
  
  try {
    // Verificar status atual
    const status = await checkSchemaStatus()
    const missingTables = status.filter(s => !s.exists).map(s => s.table)
    
    if (missingTables.length === 0) {
      console.log('✅ Todas as tabelas já existem')
      return { success: true, created: [], errors: [] }
    }
    
    console.log('🔧 Tabelas faltando:', missingTables)
    
    // Criar tabelas na ordem correta (dependências)
    if (missingTables.includes('Category')) {
      const success = await createCategoryTable()
      if (success) {
        created.push('Category')
      } else {
        errors.push('Falha ao criar tabela Category')
      }
    }
    
    if (missingTables.includes('Product')) {
      const success = await createProductTable()
      if (success) {
        created.push('Product')
      } else {
        errors.push('Falha ao criar tabela Product')
      }
    }
    
    if (missingTables.includes('ProductImage')) {
      const success = await createProductImageTable()
      if (success) {
        created.push('ProductImage')
      } else {
        errors.push('Falha ao criar tabela ProductImage')
      }
    }
    
    console.log(`✅ Schema inicializado: ${created.length} tabelas criadas`)
    
    return {
      success: errors.length === 0,
      created,
      errors
    }
    
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido'
    console.error('❌ Erro na inicialização do schema:', errorMsg)
    return {
      success: false,
      created,
      errors: [errorMsg]
    }
  }
}

/**
 * Verificar se o schema está pronto para uso
 */
export async function isSchemaReady(): Promise<boolean> {
  try {
    const status = await checkSchemaStatus()
    const criticalTables = ['Category', 'Product', 'ProductImage']
    
    return criticalTables.every(table => 
      status.find(s => s.table === table)?.exists
    )
  } catch (error) {
    console.error('❌ Erro ao verificar status do schema:', error)
    return false
  }
}

/**
 * Inserir categorias básicas se não existirem
 */
export async function seedBasicCategories(): Promise<boolean> {
  try {
    // Verificar se já existem categorias
    const count = await query('SELECT COUNT(*) as count FROM "Category"')
    if (count?.rows?.[0]?.count > 0) {
      console.log('✅ Categorias já existem')
      return true
    }
    
    const categories = [
      { id: 'cat_capas', name: 'Capas', slug: 'capas', order: 1 },
      { id: 'cat_peliculas', name: 'Películas', slug: 'peliculas', order: 2 },
      { id: 'cat_fones', name: 'Fones', slug: 'fones', order: 3 },
      { id: 'cat_carregadores', name: 'Carregadores', slug: 'carregadores', order: 4 }
    ]
    
    for (const cat of categories) {
      await query(`
        INSERT INTO "Category" ("id", "name", "slug", "order", "isActive", "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, true, NOW(), NOW())
        ON CONFLICT ("id") DO NOTHING
      `, [cat.id, cat.name, cat.slug, cat.order])
    }
    
    console.log('✅ Categorias básicas inseridas')
    return true
  } catch (error) {
    console.error('❌ Erro ao inserir categorias básicas:', error)
    return false
  }
}