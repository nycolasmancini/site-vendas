import { prisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { query as dbQuery } from '@/lib/db'

// Cache para evitar verificações repetidas
const tableStatusCache = new Map<string, { exists: boolean; timestamp: number }>()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutos

export async function checkTableExists(tableName: string): Promise<boolean> {
  // Verificar cache primeiro
  const cached = tableStatusCache.get(tableName)
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.exists
  }

  try {
    // Tentar com Prisma primeiro
    const query = Prisma.sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = ${tableName}
      ) as exists
    `
    const result = await prisma.$queryRaw<[{exists: boolean}]>(query)
    const exists = result[0].exists
    
    // Atualizar cache
    tableStatusCache.set(tableName, { exists, timestamp: Date.now() })
    
    return exists
  } catch (prismaError) {
    console.warn(`Prisma falhou para verificar ${tableName}, tentando SQL direto...`)
    
    try {
      // Fallback: usar conexão SQL direta
      const result = await dbQuery(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = 'public' 
          AND table_name = $1
        ) as exists
      `, [tableName])
      
      const exists = result?.rows?.[0]?.exists || false
      
      // Atualizar cache
      tableStatusCache.set(tableName, { exists, timestamp: Date.now() })
      
      return exists
    } catch (dbError) {
      console.error(`Erro ao verificar tabela ${tableName} com ambos os métodos:`, { prismaError, dbError })
      return false
    }
  }
}

export async function createBrandTable() {
  const maxRetries = 3
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🔧 Criando tabela Brand (tentativa ${attempt}/${maxRetries})...`)
      
      try {
        // Tentar com Prisma primeiro
        await prisma.$executeRaw`
          CREATE TABLE IF NOT EXISTS "Brand" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "name" TEXT NOT NULL,
            "order" INTEGER NOT NULL DEFAULT 0,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "Brand_pkey" PRIMARY KEY ("id")
          )
        `
        
        await prisma.$executeRaw`
          CREATE UNIQUE INDEX IF NOT EXISTS "Brand_name_key" ON "Brand"("name")
        `
        
        console.log('✅ Tabela Brand criada com Prisma')
        
      } catch (prismaError) {
        console.warn(`Prisma falhou na tentativa ${attempt}, usando SQL direto...`)
        
        // Fallback: SQL direto
        await dbQuery(`
          CREATE TABLE IF NOT EXISTS "Brand" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "name" TEXT NOT NULL,
            "order" INTEGER NOT NULL DEFAULT 0,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "Brand_pkey" PRIMARY KEY ("id")
          )
        `)
        
        await dbQuery(`
          CREATE UNIQUE INDEX IF NOT EXISTS "Brand_name_key" ON "Brand"("name")
        `)
        
        console.log('✅ Tabela Brand criada com SQL direto')
      }
      
      // Invalidar cache
      tableStatusCache.delete('Brand')
      return
      
    } catch (error) {
      console.error(`❌ Erro na tentativa ${attempt} de criar tabela Brand:`, error)
      
      if (attempt === maxRetries) {
        throw error
      }
      
      // Aguardar antes da próxima tentativa
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt))
    }
  }
}

export async function createModelTable() {
  const maxRetries = 3
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🔧 Criando tabela Model (tentativa ${attempt}/${maxRetries})...`)
      
      try {
        // Tentar com Prisma primeiro
        await prisma.$executeRaw`
          CREATE TABLE IF NOT EXISTS "Model" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "name" TEXT NOT NULL,
            "brandId" TEXT NOT NULL,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "Model_pkey" PRIMARY KEY ("id")
          )
        `
        
        await prisma.$executeRaw`
          CREATE UNIQUE INDEX IF NOT EXISTS "Model_brandId_name_key" ON "Model"("brandId", "name")
        `
        
        // Só adicionar constraint se a tabela Brand existe
        const brandExists = await checkTableExists('Brand')
        if (brandExists) {
          await prisma.$executeRaw`
            DO $$ BEGIN
              ALTER TABLE "Model" ADD CONSTRAINT "Model_brandId_fkey" 
              FOREIGN KEY ("brandId") REFERENCES "Brand"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `
        }
        
        console.log('✅ Tabela Model criada com Prisma')
        
      } catch (prismaError) {
        console.warn(`Prisma falhou na tentativa ${attempt}, usando SQL direto...`)
        
        // Fallback: SQL direto
        await dbQuery(`
          CREATE TABLE IF NOT EXISTS "Model" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "name" TEXT NOT NULL,
            "brandId" TEXT NOT NULL,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "Model_pkey" PRIMARY KEY ("id")
          )
        `)
        
        await dbQuery(`
          CREATE UNIQUE INDEX IF NOT EXISTS "Model_brandId_name_key" ON "Model"("brandId", "name")
        `)
        
        // Só adicionar constraint se a tabela Brand existe
        const brandExists = await checkTableExists('Brand')
        if (brandExists) {
          await dbQuery(`
            DO $$ BEGIN
              ALTER TABLE "Model" ADD CONSTRAINT "Model_brandId_fkey" 
              FOREIGN KEY ("brandId") REFERENCES "Brand"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `)
        }
        
        console.log('✅ Tabela Model criada com SQL direto')
      }
      
      // Invalidar cache
      tableStatusCache.delete('Model')
      return
      
    } catch (error) {
      console.error(`❌ Erro na tentativa ${attempt} de criar tabela Model:`, error)
      
      if (attempt === maxRetries) {
        throw error
      }
      
      // Aguardar antes da próxima tentativa
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt))
    }
  }
}

export async function createProductModelTable() {
  const maxRetries = 3
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🔧 Criando tabela ProductModel (tentativa ${attempt}/${maxRetries})...`)
      
      try {
        // Tentar com Prisma primeiro
        await prisma.$executeRaw`
          CREATE TABLE IF NOT EXISTS "ProductModel" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "productId" TEXT NOT NULL,
            "modelId" TEXT NOT NULL,
            "price" DOUBLE PRECISION,
            "superWholesalePrice" DOUBLE PRECISION,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "ProductModel_pkey" PRIMARY KEY ("id")
          )
        `
        
        await prisma.$executeRaw`
          CREATE UNIQUE INDEX IF NOT EXISTS "ProductModel_productId_modelId_key" 
          ON "ProductModel"("productId", "modelId")
        `
        
        // Adicionar constraints se as tabelas referenciadas existem
        const productExists = await checkTableExists('Product')
        const modelExists = await checkTableExists('Model')
        
        if (productExists) {
          await prisma.$executeRaw`
            DO $$ BEGIN
              ALTER TABLE "ProductModel" ADD CONSTRAINT "ProductModel_productId_fkey" 
              FOREIGN KEY ("productId") REFERENCES "Product"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `
        }
        
        if (modelExists) {
          await prisma.$executeRaw`
            DO $$ BEGIN
              ALTER TABLE "ProductModel" ADD CONSTRAINT "ProductModel_modelId_fkey" 
              FOREIGN KEY ("modelId") REFERENCES "Model"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `
        }
        
        console.log('✅ Tabela ProductModel criada com Prisma')
        
      } catch (prismaError) {
        console.warn(`Prisma falhou na tentativa ${attempt}, usando SQL direto...`)
        
        // Fallback: SQL direto
        await dbQuery(`
          CREATE TABLE IF NOT EXISTS "ProductModel" (
            "id" TEXT NOT NULL DEFAULT ('cm' || substring(md5(random()::text), 1, 13)),
            "productId" TEXT NOT NULL,
            "modelId" TEXT NOT NULL,
            "price" DOUBLE PRECISION,
            "superWholesalePrice" DOUBLE PRECISION,
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT "ProductModel_pkey" PRIMARY KEY ("id")
          )
        `)
        
        await dbQuery(`
          CREATE UNIQUE INDEX IF NOT EXISTS "ProductModel_productId_modelId_key" 
          ON "ProductModel"("productId", "modelId")
        `)
        
        // Adicionar constraints se as tabelas referenciadas existem
        const productExists = await checkTableExists('Product')
        const modelExists = await checkTableExists('Model')
        
        if (productExists) {
          await dbQuery(`
            DO $$ BEGIN
              ALTER TABLE "ProductModel" ADD CONSTRAINT "ProductModel_productId_fkey" 
              FOREIGN KEY ("productId") REFERENCES "Product"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `)
        }
        
        if (modelExists) {
          await dbQuery(`
            DO $$ BEGIN
              ALTER TABLE "ProductModel" ADD CONSTRAINT "ProductModel_modelId_fkey" 
              FOREIGN KEY ("modelId") REFERENCES "Model"("id") 
              ON DELETE RESTRICT ON UPDATE CASCADE;
            EXCEPTION
              WHEN duplicate_object THEN null;
            END $$;
          `)
        }
        
        console.log('✅ Tabela ProductModel criada com SQL direto')
      }
      
      // Invalidar cache
      tableStatusCache.delete('ProductModel')
      return
      
    } catch (error) {
      console.error(`❌ Erro na tentativa ${attempt} de criar tabela ProductModel:`, error)
      
      if (attempt === maxRetries) {
        throw error
      }
      
      // Aguardar antes da próxima tentativa
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt))
    }
  }
}

export async function createInitialBrands() {
  try {
    console.log('🌱 Criando marcas iniciais...')
    
    const brands = ['Apple', 'Samsung', 'Xiaomi', 'Motorola', 'LG', 'Realme', 'Asus']
    
    for (const brandName of brands) {
      try {
        // Tentar com Prisma primeiro
        try {
          await prisma.$executeRaw`
            INSERT INTO "Brand" ("name", "order", "createdAt") 
            VALUES (${brandName}, 0, CURRENT_TIMESTAMP)
            ON CONFLICT ("name") DO NOTHING
          `
        } catch (prismaError) {
          // Fallback: SQL direto
          await dbQuery(`
            INSERT INTO "Brand" ("name", "order", "createdAt") 
            VALUES ($1, 0, CURRENT_TIMESTAMP)
            ON CONFLICT ("name") DO NOTHING
          `, [brandName])
        }
        
        console.log(`✅ Marca ${brandName} criada ou já existe`)
      } catch (error) {
        console.log(`⚠️  Erro ao criar marca ${brandName}:`, error)
      }
    }
    
    console.log('✅ Marcas iniciais criadas')
  } catch (error) {
    console.error('❌ Erro ao criar marcas iniciais:', error)
  }
}

export async function ensureAllTablesExist(): Promise<boolean> {
  try {
    console.log('🔍 Verificando todas as tabelas necessárias...')
    
    const brandExists = await checkTableExists('Brand')
    const modelExists = await checkTableExists('Model')
    const productModelExists = await checkTableExists('ProductModel')
    
    // Criar tabelas na ordem correta (dependências)
    if (!brandExists) {
      await createBrandTable()
      await createInitialBrands()
    }
    
    if (!modelExists) {
      await createModelTable()
    }
    
    if (!productModelExists) {
      await createProductModelTable()
    }
    
    console.log('✅ Todas as tabelas verificadas/criadas')
    return true
    
  } catch (error) {
    console.error('❌ Erro ao garantir existência das tabelas:', error)
    return false
  }
}

// Limpar cache quando necessário
export function clearTableCache() {
  tableStatusCache.clear()
  console.log('🗑️ Cache de tabelas limpo')
}