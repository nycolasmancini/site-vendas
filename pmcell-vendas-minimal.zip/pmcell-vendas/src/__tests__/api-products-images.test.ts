import { describe, test, expect, beforeAll, afterAll } from '@jest/globals'

describe('API Products Images', () => {
  beforeAll(async () => {
    // Aguardar servidor estar disponível
    await new Promise(resolve => setTimeout(resolve, 1000))
  })

  afterAll(async () => {
    // Cleanup se necessário
  })

  test('API deve retornar URLs completas de imagem', async () => {
    const response = await fetch('http://localhost:3000/api/products')
    expect(response.status).toBe(200)
    
    const data = await response.json()
    expect(data.products).toBeDefined()
    expect(Array.isArray(data.products)).toBe(true)
    
    // Verificar se há produtos com imagens
    const productsWithImages = data.products.filter((p: any) => p.images && p.images.length > 0)
    expect(productsWithImages.length).toBeGreaterThan(0)
    
    // Verificar primeira imagem do primeiro produto
    const firstProduct = productsWithImages[0]
    const firstImage = firstProduct.images[0]
    
    expect(firstImage).toHaveProperty('id')
    expect(firstImage).toHaveProperty('url')
    expect(firstImage).toHaveProperty('thumbnailUrl')
    expect(firstImage).toHaveProperty('normalUrl')
    expect(firstImage).toHaveProperty('isMain')
    expect(firstImage).toHaveProperty('order')
    
    // URLs não devem estar vazias
    expect(firstImage.url).toBeTruthy()
    if (firstImage.thumbnailUrl) {
      expect(firstImage.thumbnailUrl).toContain('cloudinary.com')
    }
    if (firstImage.normalUrl) {
      expect(firstImage.normalUrl).toContain('cloudinary.com')
    }
  })

  test('thumbnailUrl deve funcionar quando disponível', async () => {
    const response = await fetch('http://localhost:3000/api/products')
    const data = await response.json()
    
    const imageWithThumbnail = data.products
      .flatMap((p: any) => p.images || [])
      .find((img: any) => img.thumbnailUrl && img.thumbnailUrl.includes('cloudinary.com'))
    
    if (imageWithThumbnail) {
      // Testar se a thumbnail é acessível
      const imgResponse = await fetch(imageWithThumbnail.thumbnailUrl, { method: 'HEAD' })
      expect(imgResponse.status).toBe(200)
      console.log(`✅ Thumbnail acessível: ${imageWithThumbnail.thumbnailUrl}`)
    }
  }, 10000)

  test('normalUrl deve funcionar quando disponível', async () => {
    const response = await fetch('http://localhost:3000/api/products')
    const data = await response.json()
    
    const imageWithNormal = data.products
      .flatMap((p: any) => p.images || [])
      .find((img: any) => img.normalUrl && img.normalUrl.includes('cloudinary.com'))
    
    if (imageWithNormal) {
      // Testar se a normalUrl é acessível
      const imgResponse = await fetch(imageWithNormal.normalUrl, { method: 'HEAD' })
      expect(imgResponse.status).toBe(200)
      console.log(`✅ Normal URL acessível: ${imageWithNormal.normalUrl}`)
    }
  }, 10000)
})