import { describe, test, expect, beforeAll, afterAll } from '@jest/globals'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

describe('Image URLs Validation', () => {
  beforeAll(async () => {
    // Configurar ambiente de teste se necessário
  })

  afterAll(async () => {
    await prisma.$disconnect()
  })

  test('URLs das imagens devem estar completas e válidas', async () => {
    const images = await prisma.productImage.findMany({
      where: {
        url: { contains: 'cloudinary.com' }
      },
      take: 10
    })

    expect(images.length).toBeGreaterThan(0)

    for (const image of images) {
      // URL principal deve terminar com extensão válida
      expect(image.url).toMatch(/\.(webp|jpg|jpeg|png)$/)
      
      // Não deve ter extensões duplicadas
      expect(image.url).not.toMatch(/\.(webp|jpg|jpeg|png)\.\w+$/)
      
      // cloudinaryPublicId não deve conter extensão
      if (image.cloudinaryPublicId) {
        expect(image.cloudinaryPublicId).not.toMatch(/\.(webp|jpg|jpeg|png)/)
      }
      
      // thumbnailUrl e normalUrl devem ser válidas se existirem
      if (image.thumbnailUrl) {
        expect(image.thumbnailUrl).toContain('cloudinary.com')
        expect(image.thumbnailUrl).toContain('c_fill')
        expect(image.thumbnailUrl).toContain('w_150')
      }
      
      if (image.normalUrl) {
        expect(image.normalUrl).toContain('cloudinary.com')
        expect(image.normalUrl).toContain('c_fill')
        expect(image.normalUrl).toContain('w_500')
      }
    }
  })

  test('URLs base64 devem ser válidas', async () => {
    const base64Images = await prisma.productImage.findMany({
      where: {
        url: { startsWith: 'data:' }
      },
      take: 5
    })

    for (const image of base64Images) {
      expect(image.url).toMatch(/^data:image\/(jpeg|png|webp);base64,/)
      
      // Para imagens base64, script de correção pode ter gerado URLs cloudinary
      // então apenas verificamos se a URL principal é base64
    }
  })

  test('URLs não devem estar vazias', async () => {
    const emptyUrls = await prisma.productImage.findMany({
      where: {
        url: { equals: '' }
      }
    })

    expect(emptyUrls).toHaveLength(0)
  })

  test('Cloudinary URLs devem ser acessíveis', async () => {
    // Teste de conectividade (apenas algumas amostras)
    const cloudinaryImages = await prisma.productImage.findMany({
      where: {
        url: { contains: 'cloudinary.com' }
      },
      take: 3
    })

    for (const image of cloudinaryImages) {
      // Simular requisição HEAD para verificar se a URL é válida
      const url = new URL(image.url)
      expect(url.hostname).toBe('res.cloudinary.com')
      expect(url.pathname).toContain('dlmsk8vcs') // Cloud name
    }
  }, 10000)

  test('validateUrl helper function', () => {
    // Função utilitária para validar URLs
    const validateUrl = (url: string) => {
      // Verificar se URL não tem dupla extensão
      const hasDoubleExtension = url.match(/\.(webp|jpg|jpeg|png)\.\w+$/i)
      if (hasDoubleExtension) {
        // Remover a extensão duplicada
        return url.replace(/\.(webp|jpg|jpeg|png)(\.\w+)$/i, '$2')
      }
      return url
    }

    // Testes da função de validação
    expect(validateUrl('test.webp.webp')).toBe('test.webp')
    expect(validateUrl('test.jpg.png')).toBe('test.png')
    expect(validateUrl('test.webp')).toBe('test.webp')
    expect(validateUrl('https://res.cloudinary.com/test/image.webp')).toBe('https://res.cloudinary.com/test/image.webp')
    expect(validateUrl('https://res.cloudinary.com/test/image.webp.abc')).toBe('https://res.cloudinary.com/test/image.abc')
  })
})