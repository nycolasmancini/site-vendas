-- CreateEnum
CREATE TYPE "public"."CartEventType" AS ENUM ('ADD', 'REMOVE', 'UPDATE', 'CLEAR', 'COMPLETE', 'ABANDON');

-- CreateTable
CREATE TABLE "public"."AnalyticsSession" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "whatsapp" TEXT,
    "startTime" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastActivity" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "timeOnSite" INTEGER NOT NULL DEFAULT 0,
    "whatsappCollectedAt" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AnalyticsSession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."PageView" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "path" TEXT NOT NULL,
    "title" TEXT,
    "duration" INTEGER,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PageView_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."CategoryVisit" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "categoryName" TEXT NOT NULL,
    "visits" INTEGER NOT NULL DEFAULT 1,
    "lastVisit" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hasCartItems" BOOLEAN NOT NULL DEFAULT false,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CategoryVisit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."ProductView" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "productName" TEXT NOT NULL,
    "categoryName" TEXT,
    "visits" INTEGER NOT NULL DEFAULT 1,
    "lastView" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "addedToCart" BOOLEAN NOT NULL DEFAULT false,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ProductView_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."SearchHistory" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "term" TEXT NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 1,
    "lastSearch" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SearchHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."CartEvent" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "type" "public"."CartEventType" NOT NULL,
    "productId" TEXT NOT NULL,
    "productName" TEXT,
    "quantity" INTEGER NOT NULL,
    "unitPrice" DOUBLE PRECISION,
    "totalPrice" DOUBLE PRECISION,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CartEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "AnalyticsSession_sessionId_key" ON "public"."AnalyticsSession"("sessionId");

-- CreateIndex
CREATE INDEX "AnalyticsSession_whatsapp_idx" ON "public"."AnalyticsSession"("whatsapp");

-- CreateIndex
CREATE INDEX "AnalyticsSession_lastActivity_idx" ON "public"."AnalyticsSession"("lastActivity");

-- CreateIndex
CREATE INDEX "AnalyticsSession_createdAt_idx" ON "public"."AnalyticsSession"("createdAt");

-- CreateIndex
CREATE INDEX "PageView_sessionId_idx" ON "public"."PageView"("sessionId");

-- CreateIndex
CREATE INDEX "PageView_timestamp_idx" ON "public"."PageView"("timestamp");

-- CreateIndex
CREATE INDEX "CategoryVisit_sessionId_idx" ON "public"."CategoryVisit"("sessionId");

-- CreateIndex
CREATE INDEX "CategoryVisit_timestamp_idx" ON "public"."CategoryVisit"("timestamp");

-- CreateIndex
CREATE UNIQUE INDEX "CategoryVisit_sessionId_categoryId_key" ON "public"."CategoryVisit"("sessionId", "categoryId");

-- CreateIndex
CREATE INDEX "ProductView_sessionId_idx" ON "public"."ProductView"("sessionId");

-- CreateIndex
CREATE INDEX "ProductView_productId_idx" ON "public"."ProductView"("productId");

-- CreateIndex
CREATE INDEX "ProductView_timestamp_idx" ON "public"."ProductView"("timestamp");

-- CreateIndex
CREATE UNIQUE INDEX "ProductView_sessionId_productId_key" ON "public"."ProductView"("sessionId", "productId");

-- CreateIndex
CREATE INDEX "SearchHistory_sessionId_idx" ON "public"."SearchHistory"("sessionId");

-- CreateIndex
CREATE INDEX "SearchHistory_timestamp_idx" ON "public"."SearchHistory"("timestamp");

-- CreateIndex
CREATE UNIQUE INDEX "SearchHistory_sessionId_term_key" ON "public"."SearchHistory"("sessionId", "term");

-- CreateIndex
CREATE INDEX "CartEvent_sessionId_idx" ON "public"."CartEvent"("sessionId");

-- CreateIndex
CREATE INDEX "CartEvent_type_idx" ON "public"."CartEvent"("type");

-- CreateIndex
CREATE INDEX "CartEvent_timestamp_idx" ON "public"."CartEvent"("timestamp");

-- AddForeignKey
ALTER TABLE "public"."PageView" ADD CONSTRAINT "PageView_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."CategoryVisit" ADD CONSTRAINT "CategoryVisit_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."ProductView" ADD CONSTRAINT "ProductView_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."SearchHistory" ADD CONSTRAINT "SearchHistory_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."CartEvent" ADD CONSTRAINT "CartEvent_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "public"."AnalyticsSession"("sessionId") ON DELETE CASCADE ON UPDATE CASCADE;
