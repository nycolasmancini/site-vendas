// Teste simples da API de tracking de visitas
const testData = {
  sessionId: `test-${Date.now()}`,
  whatsapp: null,
  searchTerms: ['teste'],
  categoriesVisited: [{ name: 'Fones', visits: 1, lastVisit: Date.now() }],
  productsViewed: [],
  cartData: {
    hasCart: false,
    cartValue: 0,
    cartItems: 0
  },
  status: 'active',
  whatsappCollectedAt: null
}

console.log('🧪 Testando API de tracking de visitas...')
console.log('📊 Dados de teste:', testData)

// Este script será usado para testar manualmente quando o servidor estiver rodando
console.log('✅ Script de teste criado')
console.log('💡 Para testar:')
console.log('1. npm run dev')
console.log('2. curl -X POST http://localhost:3000/api/visits/track \\')
console.log('   -H "Content-Type: application/json" \\')
console.log(`   -d '${JSON.stringify(testData)}'`)