/**
 * Testes TDD para sistema de Analytics
 * 
 * PROBLEMA: Tabelas Analytics não existem em produção causando erros 500
 * SOLUÇÃO: Verificação + fallback gracioso + migração automática
 */

const { test, expect } = require('@playwright/test')

test.describe('Sistema Analytics - Prevenção de Erros 500', () => {
  
  test('API deve verificar se tabelas existem antes de usar', async ({ page }) => {
    // Testar endpoint de verificação
    const response = await page.request.post('/api/analytics/check-tables')
    expect(response.status()).toBe(200)
    
    const data = await response.json()
    expect(data).toHaveProperty('tablesExist')
    expect(typeof data.tablesExist).toBe('boolean')
  })
  
  test('Fallback gracioso quando tabelas não existem', async ({ page }) => {
    // Simular tabelas Analytics inexistentes
    await page.route('/api/analytics/save', async route => {
      return route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({
          error: 'Tabelas Analytics não existem',
          fallback: true
        })
      })
    })
    
    await page.goto('/')
    
    // Site deve funcionar normalmente
    await expect(page.locator('[data-testid="product-card"]').first()).toBeVisible()
    
    // Não deve haver erros visíveis para o usuário
    const errors = await page.locator('[data-testid="error-message"]').count()
    expect(errors).toBe(0)
    
    // Analytics deve usar localStorage como fallback
    const localStorageData = await page.evaluate(() => {
      return localStorage.getItem('analytics-queue')
    })
    expect(localStorageData).toBeTruthy()
  })
  
  test('Script de migração automática deve funcionar', async ({ page }) => {
    const response = await page.request.post('/api/analytics/migrate')
    
    // Deve retornar sucesso ou que tabelas já existem
    expect([200, 201].includes(response.status())).toBe(true)
    
    const data = await response.json()
    expect(data.success).toBe(true)
  })
  
  test('Health check para tabelas analytics', async ({ page }) => {
    const response = await page.request.get('/api/analytics/health')
    expect(response.status()).toBe(200)
    
    const data = await response.json()
    expect(data).toHaveProperty('analyticsTablesReady')
    expect(data).toHaveProperty('canSaveAnalytics')
    expect(data).toHaveProperty('queuePendingItems')
  })
  
  test('Sistema deve funcionar sem erros 500 após migração', async ({ page }) => {
    // Primeiro executar migração
    await page.request.post('/api/analytics/migrate')
    
    // Então testar o site
    await page.goto('/')
    
    // Aguardar 5 segundos para analytics processarem
    await page.waitForTimeout(5000)
    
    // Verificar que não há erros 500 nos logs do console
    const serverErrors = []
    page.on('response', response => {
      if (response.status() === 500) {
        serverErrors.push(response.url())
      }
    })
    
    // Navegar pelo site
    await page.click('[data-testid="category-button"]')
    await page.fill('[data-testid="search-input"]', 'teste')
    await page.waitForTimeout(3000)
    
    // Não deve haver erros 500 relacionados a analytics
    const analyticsErrors = serverErrors.filter(url => url.includes('/api/analytics/'))
    expect(analyticsErrors).toHaveLength(0)
  })
})

module.exports = {
  testAnalyticsMigration: test
}