import { describe, it, expect, beforeEach, afterEach } from '@jest/globals'
import { NextRequest } from 'next/server'
import { PUT } from '@/app/api/products/[id]/images/[imageId]/route'
import { prisma } from '@/lib/prisma'

describe('Product Images API - PUT /api/products/[id]/images/[imageId]', () => {
  const mockProductId = 'test-product-id'
  const mockImageId = 'test-image-id'
  const mockSecondImageId = 'test-image-id-2'

  beforeEach(async () => {
    // Limpar dados de teste
    try {
      await prisma.productImage.deleteMany({
        where: { productId: mockProductId }
      })
    } catch (error) {
      // Ignorar erro se tabela não existir
    }

    try {
      await prisma.product.delete({
        where: { id: mockProductId }
      })
    } catch (error) {
      // Ignorar erro se produto não existir
    }

    // Criar categoria de teste se não existir
    let testCategory
    try {
      testCategory = await prisma.category.findFirst()
      if (!testCategory) {
        testCategory = await prisma.category.create({
          data: {
            name: 'Test Category',
            slug: 'test-category'
          }
        })
      }
    } catch (error) {
      console.log('Categoria já existe ou erro criando categoria:', error)
    }

    // Criar produto de teste
    try {
      await prisma.product.create({
        data: {
          id: mockProductId,
          name: 'Test Product',
          price: 100,
          categoryId: testCategory?.id || 'default-category'
        }
      })
    } catch (error) {
      console.log('Produto já existe ou erro criando produto:', error)
    }

    // Criar imagens de teste usando safeProductImageOperation
    try {
      const { safeProductImageOperation } = await import('@/lib/prisma-helpers')
      
      await safeProductImageOperation(() =>
        prisma.productImage.create({
          data: {
            id: mockImageId,
            productId: mockProductId,
            url: 'https://test.com/image1.jpg',
            fileName: 'image1.jpg',
            order: 0,
            isMain: false
          }
        })
      )

      await safeProductImageOperation(() =>
        prisma.productImage.create({
          data: {
            id: mockSecondImageId,
            productId: mockProductId,
            url: 'https://test.com/image2.jpg',
            fileName: 'image2.jpg',
            order: 1,
            isMain: true
          }
        })
      )
    } catch (error) {
      console.log('Erro criando imagens de teste:', error)
    }
  })

  afterEach(async () => {
    // Limpar dados de teste
    try {
      await prisma.productImage.deleteMany({
        where: { productId: mockProductId }
      })
      await prisma.product.delete({
        where: { id: mockProductId }
      })
    } catch (error) {
      // Ignorar erros de limpeza
    }
  })

  it('deve trocar a imagem principal com sucesso', async () => {
    const request = new NextRequest('http://localhost:3000/api/products/test/images/test', {
      method: 'PUT',
      body: JSON.stringify({ action: 'set_main' })
    })

    const mockParams = Promise.resolve({ 
      id: mockProductId, 
      imageId: mockImageId 
    })

    const response = await PUT(request, { params: mockParams })
    const result = await response.json()

    expect(response.status).toBe(200)
    expect(result.message).toBe('Imagem principal atualizada com sucesso')

    // Verificar se apenas a imagem correta está marcada como principal
    const { safeProductImageOperation } = await import('@/lib/prisma-helpers')
    
    const updatedImage = await safeProductImageOperation(() =>
      prisma.productImage.findUnique({
        where: { id: mockImageId }
      })
    )
    
    const otherImage = await safeProductImageOperation(() =>
      prisma.productImage.findUnique({
        where: { id: mockSecondImageId }
      })
    )

    expect(updatedImage?.isMain).toBe(true)
    expect(otherImage?.isMain).toBe(false)
  })

  it('deve retornar erro 404 para imagem inexistente', async () => {
    const request = new NextRequest('http://localhost:3000/api/products/test/images/test', {
      method: 'PUT',
      body: JSON.stringify({ action: 'set_main' })
    })

    const mockParams = Promise.resolve({ 
      id: mockProductId, 
      imageId: 'image-inexistente' 
    })

    const response = await PUT(request, { params: mockParams })
    const result = await response.json()

    expect(response.status).toBe(404)
    expect(result.error).toBe('Imagem não encontrada')
  })

  it('deve retornar erro 400 para ação inválida', async () => {
    const request = new NextRequest('http://localhost:3000/api/products/test/images/test', {
      method: 'PUT',
      body: JSON.stringify({ action: 'invalid_action' })
    })

    const mockParams = Promise.resolve({ 
      id: mockProductId, 
      imageId: mockImageId 
    })

    const response = await PUT(request, { params: mockParams })
    const result = await response.json()

    expect(response.status).toBe(400)
    expect(result.error).toBe('Ação inválida')
  })

  it('deve lidar graciosamente com erro P2021 (tabela não existe)', async () => {
    // Este teste verifica se o wrapper seguro está funcionando
    // Em um ambiente onde a tabela não existe, o wrapper deve criar a tabela automaticamente
    const request = new NextRequest('http://localhost:3000/api/products/test/images/test', {
      method: 'PUT',
      body: JSON.stringify({ action: 'set_main' })
    })

    const mockParams = Promise.resolve({ 
      id: mockProductId, 
      imageId: mockImageId 
    })

    const response = await PUT(request, { params: mockParams })
    
    // O teste deve passar independentemente se a tabela existe ou não
    // porque o wrapper seguro deve criar a tabela se necessário
    expect([200, 404].includes(response.status)).toBe(true)
  })
})