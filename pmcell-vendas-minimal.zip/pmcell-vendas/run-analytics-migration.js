/**
 * Script para executar migração Analytics em produção via API
 * 
 * Uso:
 * 1. Local: node run-analytics-migration.js
 * 2. Produção: node run-analytics-migration.js https://pmcellvendas.vercel.app
 */

const https = require('https')
const http = require('http')

async function runMigration(baseUrl = 'http://localhost:3000') {
  return new Promise((resolve, reject) => {
    const url = `${baseUrl}/api/analytics/migrate`
    const isHttps = url.startsWith('https')
    const client = isHttps ? https : http
    
    console.log(`🔄 Executando migração Analytics em: ${url}`)
    
    const postData = JSON.stringify({})
    
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: 30000
    }
    
    const req = client.request(url, options, (res) => {
      let data = ''
      
      res.on('data', (chunk) => {
        data += chunk
      })
      
      res.on('end', () => {
        try {
          const result = JSON.parse(data)
          
          if (res.statusCode === 200) {
            console.log('✅ Migração executada com sucesso!')
            console.log('📊 Resultado:', result.message)
            resolve(result)
          } else {
            console.error(`❌ Erro HTTP ${res.statusCode}:`, result.error)
            reject(new Error(result.error || `HTTP ${res.statusCode}`))
          }
        } catch (parseError) {
          console.error('❌ Erro ao parsear resposta:', data)
          reject(parseError)
        }
      })
    })
    
    req.on('error', (error) => {
      console.error('❌ Erro na requisição:', error.message)
      reject(error)
    })
    
    req.on('timeout', () => {
      console.error('❌ Timeout na migração (30s)')
      req.destroy()
      reject(new Error('Timeout'))
    })
    
    req.write(postData)
    req.end()
  })
}

async function checkHealth(baseUrl = 'http://localhost:3000') {
  return new Promise((resolve, reject) => {
    const url = `${baseUrl}/api/analytics/health`
    const isHttps = url.startsWith('https')
    const client = isHttps ? https : http
    
    console.log(`🔍 Verificando health check: ${url}`)
    
    const req = client.get(url, { timeout: 10000 }, (res) => {
      let data = ''
      
      res.on('data', (chunk) => {
        data += chunk
      })
      
      res.on('end', () => {
        try {
          const result = JSON.parse(data)
          console.log('📊 Health Check:', {
            analyticsReady: result.analyticsTablesReady,
            queueItems: result.queuePendingItems,
            canSave: result.canSaveAnalytics
          })
          resolve(result)
        } catch (error) {
          reject(error)
        }
      })
    })
    
    req.on('error', reject)
    req.on('timeout', () => {
      req.destroy()
      reject(new Error('Health check timeout'))
    })
  })
}

async function main() {
  const baseUrl = process.argv[2] || 'http://localhost:3000'
  
  console.log('🚀 Iniciando migração Analytics...')
  console.log(`📍 URL: ${baseUrl}`)
  
  try {
    // 1. Health check inicial
    console.log('\n1️⃣ Health check inicial...')
    const initialHealth = await checkHealth(baseUrl)
    
    if (initialHealth.analyticsTablesReady) {
      console.log('✅ Tabelas Analytics já existem!')
      return
    }
    
    // 2. Executar migração
    console.log('\n2️⃣ Executando migração...')
    await runMigration(baseUrl)
    
    // 3. Health check final
    console.log('\n3️⃣ Health check final...')
    await new Promise(resolve => setTimeout(resolve, 2000)) // Aguardar 2s
    const finalHealth = await checkHealth(baseUrl)
    
    if (finalHealth.analyticsTablesReady) {
      console.log('🎉 Migração Analytics concluída com sucesso!')
      console.log('✅ Sistema pronto para uso')
    } else {
      console.error('❌ Migração não foi efetiva')
      process.exit(1)
    }
    
  } catch (error) {
    console.error('💥 Falha na migração:', error.message)
    process.exit(1)
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  main()
}

module.exports = { runMigration, checkHealth }