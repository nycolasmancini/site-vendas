const fs = require('fs')
const path = require('path')

console.log('🧪 Teste manual do sistema de tracking de visitas')

// 1. Verificar se diretório data existe
const dataDir = path.join(process.cwd(), 'data')
console.log(`📁 Verificando diretório: ${dataDir}`)

if (!fs.existsSync(dataDir)) {
  console.log('📁 Criando diretório data...')
  fs.mkdirSync(dataDir, { recursive: true })
  console.log('✅ Diretório criado')
} else {
  console.log('✅ Diretório já existe')
}

// 2. Verificar permissões
try {
  fs.accessSync(dataDir, fs.constants.W_OK)
  console.log('✅ Permissões de escrita OK')
} catch (error) {
  console.error('❌ Erro de permissões:', error.message)
  process.exit(1)
}

// 3. Criar arquivo de teste
const testFile = path.join(dataDir, 'visits-tracking.json')
const testData = [{
  sessionId: 'test-' + Date.now(),
  whatsapp: null,
  searchTerms: ['teste'],
  categoriesVisited: [{ name: 'Fones', visits: 1, lastVisit: Date.now() }],
  productsViewed: [],
  hasCart: false,
  cartValue: 0,
  cartItems: 0,
  status: 'active',
  startTime: new Date().toISOString(),
  lastActivity: new Date().toISOString(),
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
}]

console.log('💾 Tentando criar arquivo de teste...')

try {
  fs.writeFileSync(testFile, JSON.stringify(testData, null, 2))
  console.log('✅ Arquivo criado com sucesso!')
  
  // 4. Verificar se arquivo existe e tem conteúdo
  if (fs.existsSync(testFile)) {
    const stats = fs.statSync(testFile)
    console.log(`📊 Tamanho do arquivo: ${stats.size} bytes`)
    
    const content = fs.readFileSync(testFile, 'utf8')
    const parsed = JSON.parse(content)
    console.log(`📊 Visitas no arquivo: ${parsed.length}`)
    console.log('📊 Primeira visita:', {
      sessionId: parsed[0].sessionId,
      status: parsed[0].status,
      searchTerms: parsed[0].searchTerms
    })
  } else {
    console.error('❌ Arquivo não foi criado!')
  }
  
} catch (error) {
  console.error('❌ Erro ao criar arquivo:', error.message)
  process.exit(1)
}

console.log('✅ Teste concluído com sucesso!')
console.log('🔥 Agora teste navegando no site para ver se as visitas são salvas automaticamente')