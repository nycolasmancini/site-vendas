// Script para testar a funcionalidade de visitas
const fs = require('fs')
const path = require('path')

const CARTS_FILE = path.join(process.cwd(), 'data', 'abandoned-carts.json')

// Dados de teste para simular visitas
const testCarts = [
  {
    sessionId: 'test-session-1',
    whatsapp: '11987654321',
    cartData: {
      items: [
        {
          id: 'item-1',
          productId: 'prod-1',
          name: 'Capa iPhone 14',
          quantity: 2,
          unitPrice: 25.00,
          modelName: 'iPhone 14'
        },
        {
          id: 'item-2',
          productId: 'prod-2',
          name: 'Película de Vidro',
          quantity: 1,
          unitPrice: 15.00
        }
      ],
      total: 65.00
    },
    analyticsData: {
      sessionId: 'test-session-1',
      timeOnSite: 300000, // 5 minutos
      categoriesVisited: [
        { name: 'Capas', visits: 3, lastVisit: Date.now() },
        { name: 'Películas', visits: 1, lastVisit: Date.now() - 60000 }
      ],
      searchTerms: [
        { term: 'iphone 14', count: 2, lastSearch: Date.now() },
        { term: 'capa', count: 1, lastSearch: Date.now() - 30000 }
      ],
      productsViewed: [
        { id: 'prod-1', name: 'Capa iPhone 14', category: 'Capas', visits: 5, lastView: Date.now() },
        { id: 'prod-2', name: 'Película de Vidro', category: 'Películas', visits: 2, lastView: Date.now() - 45000 }
      ],
      whatsappCollected: '11987654321',
      whatsappCollectedAt: Date.now() - 120000
    },
    lastActivity: Date.now() - 60000, // 1 minuto atrás
    webhookSent: false,
    createdAt: Date.now() - 300000, // Criado 5 minutos atrás
    contacted: false
  },
  {
    sessionId: 'test-session-2',
    whatsapp: '11912345678',
    cartData: {
      items: [
        {
          id: 'item-3',
          productId: 'prod-3',
          name: 'Carregador USB-C',
          quantity: 1,
          unitPrice: 35.00
        }
      ],
      total: 35.00
    },
    analyticsData: {
      sessionId: 'test-session-2',
      timeOnSite: 180000, // 3 minutos
      categoriesVisited: [
        { name: 'Acessórios', visits: 2, lastVisit: Date.now() }
      ],
      searchTerms: [
        { term: 'carregador', count: 1, lastSearch: Date.now() }
      ],
      productsViewed: [
        { id: 'prod-3', name: 'Carregador USB-C', category: 'Acessórios', visits: 1, lastView: Date.now() }
      ],
      whatsappCollected: '11912345678',
      whatsappCollectedAt: Date.now() - 60000
    },
    lastActivity: Date.now() - 10000, // 10 segundos atrás (ativo)
    webhookSent: false,
    createdAt: Date.now() - 180000, // Criado 3 minutos atrás
    contacted: false
  },
  {
    sessionId: 'test-session-3',
    whatsapp: '11999887766',
    cartData: {
      items: [
        {
          id: 'item-4',
          productId: 'prod-4',
          name: 'Fone de Ouvido Bluetooth',
          quantity: 1,
          unitPrice: 89.90
        },
        {
          id: 'item-5',
          productId: 'prod-5',
          name: 'Case para AirPods',
          quantity: 2,
          unitPrice: 22.50
        }
      ],
      total: 134.90
    },
    analyticsData: {
      sessionId: 'test-session-3',
      timeOnSite: 600000, // 10 minutos
      categoriesVisited: [
        { name: 'Fones', visits: 4, lastVisit: Date.now() },
        { name: 'Cases', visits: 2, lastVisit: Date.now() - 30000 }
      ],
      searchTerms: [
        { term: 'fone bluetooth', count: 3, lastSearch: Date.now() },
        { term: 'airpods', count: 2, lastSearch: Date.now() - 15000 }
      ],
      productsViewed: [
        { id: 'prod-4', name: 'Fone de Ouvido Bluetooth', category: 'Fones', visits: 8, lastView: Date.now() },
        { id: 'prod-5', name: 'Case para AirPods', category: 'Cases', visits: 3, lastView: Date.now() - 20000 }
      ],
      whatsappCollected: '11999887766',
      whatsappCollectedAt: Date.now() - 480000
    },
    lastActivity: Date.now() - 1800000, // 30 minutos atrás (abandonado)
    webhookSent: true,
    createdAt: Date.now() - 600000, // Criado 10 minutos atrás
    contacted: true // Finalizado
  }
]

// Função para garantir que o diretório existe
function ensureDataDirectory() {
  const dataDir = path.join(process.cwd(), 'data')
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true })
    console.log('📁 Diretório data/ criado')
  }
}

// Criar dados de teste
function createTestData() {
  ensureDataDirectory()
  
  try {
    fs.writeFileSync(CARTS_FILE, JSON.stringify(testCarts, null, 2))
    console.log('✅ Dados de teste criados com sucesso!')
    console.log(`📁 Arquivo: ${CARTS_FILE}`)
    console.log(`📊 ${testCarts.length} visitas de teste criadas:`)
    
    testCarts.forEach((cart, index) => {
      console.log(`   ${index + 1}. ${cart.whatsapp} - ${cart.cartData.items.length} itens - R$ ${cart.cartData.total.toFixed(2)}`)
    })
    
  } catch (error) {
    console.error('❌ Erro ao criar dados de teste:', error)
  }
}

// Executar
createTestData()