#!/usr/bin/env node

const BASE_URL = 'http://localhost:3000'

// Dados de teste realísticos
const testPayload = {
  sessionId: `test_${Date.now()}`,
  whatsapp: "5511999888777",
  startTime: Date.now() - 300000, // 5 minutos atrás
  lastActivity: Date.now(),
  timeOnSite: 300,
  whatsappCollectedAt: Date.now(),
  categoriesVisited: [
    {
      name: "Fones de Ouvido",
      categoryId: "fones",
      visits: 3,
      lastVisit: Date.now() - 120000
    },
    {
      name: "Capinhas",
      categoryId: "capinhas", 
      visits: 1,
      lastVisit: Date.now() - 60000
    }
  ],
  searchTerms: [
    {
      term: "bluetooth",
      count: 2,
      lastSearch: Date.now() - 90000
    }
  ],
  productsViewed: [
    {
      id: "test_product_123",
      name: "Fone Bluetooth Test",
      category: "Fones de Ouvido",
      visits: 2,
      lastView: Date.now() - 60000
    }
  ],
  cartEvents: [
    {
      type: "add",
      productId: "test_product_123",
      productName: "Fone Bluetooth Test",
      quantity: 2,
      unitPrice: 150.00,
      totalPrice: 300.00,
      timestamp: Date.now() - 30000
    }
  ]
}

async function testAPI(url, method = 'GET', body = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
    }
  }
  
  if (body) {
    options.body = JSON.stringify(body)
  }

  try {
    console.log(`\n🧪 Testando ${method} ${url}`)
    const response = await fetch(url, options)
    const data = await response.text()
    
    console.log(`   Status: ${response.status}`)
    
    try {
      const jsonData = JSON.parse(data)
      console.log(`   Response:`, jsonData)
      return { status: response.status, data: jsonData }
    } catch {
      console.log(`   Response (text):`, data.substring(0, 200))
      return { status: response.status, data: data }
    }
  } catch (error) {
    console.log(`   ❌ Erro:`, error.message)
    return { status: 0, error: error.message }
  }
}

async function runTests() {
  console.log('🔬 INICIANDO DIAGNÓSTICO COMPLETO DE APIS')
  console.log('=' * 50)

  // Teste 1: Analytics Save (novo)
  await testAPI(`${BASE_URL}/api/analytics/save`, 'POST', testPayload)

  // Teste 2: Analytics Track (antigo - deve dar 405?)
  await testAPI(`${BASE_URL}/api/analytics/track`, 'POST', testPayload)

  // Teste 3: Analytics Sessions
  await testAPI(`${BASE_URL}/api/analytics/sessions`)

  // Teste 4: Analytics Session Detail
  await testAPI(`${BASE_URL}/api/analytics/session/${testPayload.sessionId}`)

  // Teste 5: Webhook Settings
  await testAPI(`${BASE_URL}/api/webhook-settings`)

  // Teste 6: Cart Simple Update
  const cartPayload = {
    sessionId: testPayload.sessionId,
    whatsapp: testPayload.whatsapp,
    cartData: {
      items: [
        {
          id: "test_item_123",
          productId: "test_product_123",
          name: "Fone Bluetooth Test",
          quantity: 2,
          unitPrice: 150.00
        }
      ],
      total: 300.00
    },
    analyticsData: testPayload,
    lastActivity: Date.now()
  }
  
  await testAPI(`${BASE_URL}/api/cart/simple-update`, 'POST', cartPayload)

  console.log('\n🏁 DIAGNÓSTICO CONCLUÍDO')
}

runTests().catch(console.error)