#!/usr/bin/env node

/**
 * Teste para verificar se o PATCH de status do produto funciona corretamente
 */

const TEST_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://pmcellvendas.vercel.app' 
  : 'http://localhost:3000'

async function testProductStatusToggle() {
  console.log('🧪 Iniciando teste de toggle de status do produto...')
  
  try {
    // 1. Primeiro, buscar um produto existente
    console.log('📋 Passo 1: Buscando produtos...')
    const productsResponse = await fetch(`${TEST_BASE_URL}/api/products?admin=true`)
    
    if (!productsResponse.ok) {
      throw new Error(`Erro ao buscar produtos: ${productsResponse.status}`)
    }
    
    const productsData = await productsResponse.json()
    const products = productsData.products || []
    
    if (products.length === 0) {
      console.log('⚠️ Nenhum produto encontrado para testar')
      return
    }
    
    const testProduct = products[0]
    console.log(`✅ Produto de teste encontrado: ${testProduct.name} (Status atual: ${testProduct.isActive})`)
    
    // 2. Testar toggle de status usando PATCH
    console.log('📋 Passo 2: Testando toggle de status...')
    const originalStatus = testProduct.isActive
    const newStatus = !originalStatus
    
    const patchResponse = await fetch(`${TEST_BASE_URL}/api/products/${testProduct.id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ isActive: newStatus }),
    })
    
    if (!patchResponse.ok) {
      const errorText = await patchResponse.text()
      throw new Error(`Erro no PATCH: ${patchResponse.status} - ${errorText}`)
    }
    
    const updatedProduct = await patchResponse.json()
    console.log(`✅ Status atualizado com sucesso: ${originalStatus} → ${updatedProduct.isActive}`)
    
    // 3. Verificar se outros campos não foram afetados
    console.log('📋 Passo 3: Verificando integridade dos dados...')
    const requiredFields = ['name', 'description', 'price', 'categoryId']
    const missingFields = requiredFields.filter(field => !updatedProduct[field])
    
    if (missingFields.length > 0) {
      console.error(`❌ Campos perdidos durante update: ${missingFields.join(', ')}`)
      return false
    }
    
    console.log('✅ Todos os campos essenciais mantidos')
    
    // 4. Restaurar status original
    console.log('📋 Passo 4: Restaurando status original...')
    const restoreResponse = await fetch(`${TEST_BASE_URL}/api/products/${testProduct.id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ isActive: originalStatus }),
    })
    
    if (!restoreResponse.ok) {
      console.warn('⚠️ Não foi possível restaurar status original')
    } else {
      console.log('✅ Status original restaurado')
    }
    
    console.log('🎉 Teste de toggle de status concluído com sucesso!')
    return true
    
  } catch (error) {
    console.error('❌ Erro no teste:', error.message)
    return false
  }
}

// Executar teste se chamado diretamente
if (require.main === module) {
  testProductStatusToggle()
    .then(success => {
      process.exit(success ? 0 : 1)
    })
    .catch(error => {
      console.error('💥 Erro crítico:', error)
      process.exit(1)
    })
}

module.exports = { testProductStatusToggle }