const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function fixImageUrls() {
  console.log('🔧 Iniciando correção de URLs das imagens...')
  
  try {
    // Buscar todas as imagens com URLs problemáticas
    const images = await prisma.productImage.findMany({
      where: {
        OR: [
          { url: { contains: 'cloudinary.com' } },
          { cloudinaryPublicId: { not: null } }
        ]
      }
    })

    console.log(`📊 Encontradas ${images.length} imagens para verificar`)

    let correctedCount = 0
    let skippedCount = 0

    for (const image of images) {
      let needsUpdate = false
      const updates = {}

      // Corrigir URL principal se estiver problemática
      if (image.url && image.url.includes('cloudinary.com')) {
        let correctedUrl = image.url
        
        // Remover extensões duplicadas como .webp_1756648343151.webp
        correctedUrl = correctedUrl.replace(/\.webp_\d+\.webp$/, '.webp')
        
        // Se não tem extensão, adicionar .webp
        if (!correctedUrl.match(/\.(webp|jpg|jpeg|png)$/)) {
          correctedUrl = `${correctedUrl}.webp`
        }
        
        if (correctedUrl !== image.url) {
          updates.url = correctedUrl
          needsUpdate = true
          console.log(`🔧 Corrigindo URL: ${image.url} → ${correctedUrl}`)
        }
      }

      // Corrigir cloudinaryPublicId se contém extensão duplicada
      if (image.cloudinaryPublicId && image.cloudinaryPublicId.includes('.webp')) {
        // Remover extensão duplicada
        const cleanPublicId = image.cloudinaryPublicId
          .replace(/\.webp(_\w+)?$/, '')
          .replace(/_\d+$/, '') // Remover timestamp final se presente
        
        updates.cloudinaryPublicId = cleanPublicId
        needsUpdate = true
        console.log(`🔧 Corrigindo PublicId: ${image.cloudinaryPublicId} → ${cleanPublicId}`)
      }

      // Gerar URLs corretas para thumbnail e normal se cloudinaryPublicId existe
      if (image.cloudinaryPublicId || updates.cloudinaryPublicId) {
        const publicId = updates.cloudinaryPublicId || image.cloudinaryPublicId
        const basePublicId = publicId.replace(/\.webp.*/, '')
        
        // Gerar URLs otimizadas corretas
        updates.thumbnailUrl = `https://res.cloudinary.com/dlmsk8vcs/image/upload/c_fill,f_auto,h_150,q_70,w_150/v1/${basePublicId}`
        updates.normalUrl = `https://res.cloudinary.com/dlmsk8vcs/image/upload/c_fill,f_auto,h_500,q_80,w_500/v1/${basePublicId}`
        needsUpdate = true
        
        console.log(`📸 Gerando URLs otimizadas para: ${basePublicId}`)
      }

      if (needsUpdate) {
        try {
          await prisma.productImage.update({
            where: { id: image.id },
            data: updates
          })
          correctedCount++
          console.log(`✅ Imagem ${image.id} corrigida`)
        } catch (error) {
          console.error(`❌ Erro ao corrigir imagem ${image.id}:`, error.message)
        }
      } else {
        skippedCount++
      }
    }

    console.log(`\n📊 Resumo da correção:`)
    console.log(`✅ Imagens corrigidas: ${correctedCount}`)
    console.log(`⏭️ Imagens ignoradas: ${skippedCount}`)
    console.log(`📝 Total processadas: ${images.length}`)

    // Verificar algumas URLs corrigidas
    console.log('\n🔍 Verificando resultados...')
    const sampleImages = await prisma.productImage.findMany({
      take: 3,
      where: {
        url: { contains: 'cloudinary.com' }
      },
      select: {
        id: true,
        url: true,
        thumbnailUrl: true,
        normalUrl: true,
        cloudinaryPublicId: true
      }
    })

    sampleImages.forEach((img, index) => {
      console.log(`\n📸 Amostra ${index + 1}:`)
      console.log(`   URL: ${img.url}`)
      console.log(`   Thumbnail: ${img.thumbnailUrl}`)
      console.log(`   Normal: ${img.normalUrl}`)
      console.log(`   PublicId: ${img.cloudinaryPublicId}`)
    })

  } catch (error) {
    console.error('❌ Erro durante a correção:', error)
  } finally {
    await prisma.$disconnect()
  }
}

// Executar apenas se chamado diretamente
if (require.main === module) {
  fixImageUrls()
    .then(() => {
      console.log('\n🎉 Correção de URLs concluída!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('💥 Falha na correção:', error)
      process.exit(1)
    })
}

module.exports = { fixImageUrls }