#!/usr/bin/env node

// Script para inicializar o banco de dados em produção via API
const PRODUCTION_URL = 'https://pmcellvendas.vercel.app'

async function initProductionDatabase() {
  try {
    console.log('🔄 Inicializando banco de dados em produção...')
    
    const response = await fetch(`${PRODUCTION_URL}/api/init-db`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      }
    })

    const result = await response.text()
    
    console.log(`Status: ${response.status}`)
    
    try {
      const jsonResult = JSON.parse(result)
      console.log('Response:', JSON.stringify(jsonResult, null, 2))
    } catch {
      console.log('Response (text):', result)
    }

    if (response.ok) {
      console.log('✅ Banco de dados inicializado com sucesso!')
      return true
    } else {
      console.log('❌ Falha ao inicializar banco de dados')
      return false
    }
    
  } catch (error) {
    console.error('❌ Erro ao conectar com a API:', error.message)
    return false
  }
}

async function main() {
  console.log('🚀 SCRIPT DE INICIALIZAÇÃO DO BANCO EM PRODUÇÃO')
  console.log('=' * 50)
  
  const success = await initProductionDatabase()
  
  if (success) {
    console.log('\n🎉 Inicialização concluída! Aguarde alguns segundos e teste novamente.')
  } else {
    console.log('\n❌ Inicialização falhou. Verifique os logs de produção.')
    process.exit(1)
  }
}

main().catch(console.error)