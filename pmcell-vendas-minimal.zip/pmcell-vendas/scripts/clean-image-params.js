const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function cleanImageParams() {
  console.log('🧹 Iniciando limpeza de parâmetros das URLs...')
  
  try {
    // Buscar todas as imagens com parâmetros de query
    const images = await prisma.productImage.findMany({
      where: {
        OR: [
          { url: { contains: '?_a=' } },
          { thumbnailUrl: { contains: '?_a=' } },
          { normalUrl: { contains: '?_a=' } }
        ]
      }
    })

    console.log(`📊 Encontradas ${images.length} imagens com parâmetros para limpar`)

    let cleanedCount = 0

    for (const image of images) {
      const updates = {}
      let needsUpdate = false

      // Limpar URL principal
      if (image.url && image.url.includes('?_a=')) {
        updates.url = image.url.split('?')[0]
        needsUpdate = true
        console.log(`🧹 Limpando URL: ${image.url} → ${updates.url}`)
      }

      // Limpar thumbnailUrl
      if (image.thumbnailUrl && image.thumbnailUrl.includes('?_a=')) {
        updates.thumbnailUrl = image.thumbnailUrl.split('?')[0]
        needsUpdate = true
        console.log(`🧹 Limpando thumbnail: ${image.thumbnailUrl} → ${updates.thumbnailUrl}`)
      }

      // Limpar normalUrl
      if (image.normalUrl && image.normalUrl.includes('?_a=')) {
        updates.normalUrl = image.normalUrl.split('?')[0]
        needsUpdate = true
        console.log(`🧹 Limpando normal: ${image.normalUrl} → ${updates.normalUrl}`)
      }

      if (needsUpdate) {
        try {
          await prisma.productImage.update({
            where: { id: image.id },
            data: updates
          })
          cleanedCount++
          console.log(`✅ Imagem ${image.id} limpa`)
        } catch (error) {
          console.error(`❌ Erro ao limpar imagem ${image.id}:`, error.message)
        }
      }
    }

    console.log(`\n📊 Resumo da limpeza:`)
    console.log(`🧹 Imagens limpas: ${cleanedCount}`)
    console.log(`📝 Total processadas: ${images.length}`)

    // Verificar algumas URLs limpas
    console.log('\n🔍 Verificando resultados...')
    const sampleImages = await prisma.productImage.findMany({
      take: 3,
      where: {
        url: { contains: 'cloudinary.com' }
      },
      select: {
        id: true,
        url: true,
        thumbnailUrl: true,
        normalUrl: true
      }
    })

    sampleImages.forEach((img, index) => {
      console.log(`\n📸 Amostra ${index + 1}:`)
      console.log(`   URL: ${img.url}`)
      console.log(`   Thumbnail: ${img.thumbnailUrl}`)
      console.log(`   Normal: ${img.normalUrl}`)
      
      // Verificar se ainda tem parâmetros
      const hasParams = [img.url, img.thumbnailUrl, img.normalUrl]
        .some(url => url && url.includes('?'))
      
      if (hasParams) {
        console.log(`   ⚠️ Ainda contém parâmetros!`)
      } else {
        console.log(`   ✅ URLs limpas`)
      }
    })

  } catch (error) {
    console.error('❌ Erro durante a limpeza:', error)
  } finally {
    await prisma.$disconnect()
  }
}

// Executar apenas se chamado diretamente
if (require.main === module) {
  cleanImageParams()
    .then(() => {
      console.log('\n🎉 Limpeza de parâmetros concluída!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('💥 Falha na limpeza:', error)
      process.exit(1)
    })
}

module.exports = { cleanImageParams }