// Script para testar sincronização de produtos em tempo real
const https = require('https');

// Configurar para aceitar certificados self-signed em desenvolvimento
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

const BASE_URL = process.env.NEXTAUTH_URL || 'http://localhost:3000';

async function testProductSync() {
  console.log('🧪 Iniciando teste de sincronização de produtos...\n');
  
  try {
    // 1. Testar status do cache
    console.log('1️⃣ Testando status do cache...');
    const cacheResponse = await fetch(`${BASE_URL}/api/products/sync`);
    const cacheData = await cacheResponse.json();
    console.log('Cache status:', cacheData);
    console.log('✅ Cache OK\n');
    
    // 2. Testar API de produtos sem cache
    console.log('2️⃣ Testando API de produtos sem cache...');
    const productsResponse = await fetch(`${BASE_URL}/api/products?refresh=true&t=${Date.now()}`, {
      headers: {
        'Cache-Control': 'no-cache'
      }
    });
    const productsData = await productsResponse.json();
    console.log('Produtos encontrados:', productsData.products?.length || 0);
    console.log('Headers de cache:', productsResponse.headers.get('cache-control'));
    console.log('✅ API de produtos OK\n');
    
    // 3. Testar webhook de sincronização
    console.log('3️⃣ Testando webhook de sincronização...');
    const syncResponse = await fetch(`${BASE_URL}/api/products/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    const syncData = await syncResponse.json();
    console.log('Sincronização:', syncData);
    console.log('✅ Webhook OK\n');
    
    console.log('🎉 Todos os testes passaram! Sistema de sincronização está funcionando.');
    
  } catch (error) {
    console.error('❌ Erro nos testes:', error.message);
    
    // Testar se servidor está rodando
    try {
      const healthCheck = await fetch(`${BASE_URL}/`);
      if (healthCheck.ok) {
        console.log('✅ Servidor está rodando');
      } else {
        console.log('❌ Servidor retornou erro:', healthCheck.status);
      }
    } catch (serverError) {
      console.log('❌ Servidor não está rodando. Execute "npm run dev" primeiro.');
    }
  }
}

if (require.main === module) {
  testProductSync();
}

module.exports = testProductSync;