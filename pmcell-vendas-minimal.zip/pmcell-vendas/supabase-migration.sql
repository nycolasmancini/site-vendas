-- SQL para criar tabelas de analytics no Supabase
-- Seguro para executar múltiplas vezes

-- Criar tipo ENUM apenas se não existir
DO $$ BEGIN
    CREATE TYPE "CartEventType" AS ENUM ('ADD', 'REMOVE', 'UPDATE', 'CLEAR', 'COMPLETE', 'ABANDON');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Criar tabela AnalyticsSession se não existir
CREATE TABLE IF NOT EXISTS "AnalyticsSession" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "whatsapp" TEXT,
    "startTime" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastActivity" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "timeOnSite" INTEGER NOT NULL DEFAULT 0,
    "whatsappCollectedAt" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AnalyticsSession_pkey" PRIMARY KEY ("id")
);

-- Criar tabela PageView se não existir
CREATE TABLE IF NOT EXISTS "PageView" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "path" TEXT NOT NULL,
    "title" TEXT,
    "duration" INTEGER,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PageView_pkey" PRIMARY KEY ("id")
);

-- Criar tabela CategoryVisit se não existir
CREATE TABLE IF NOT EXISTS "CategoryVisit" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "categoryName" TEXT NOT NULL,
    "visits" INTEGER NOT NULL DEFAULT 1,
    "lastVisit" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hasCartItems" BOOLEAN NOT NULL DEFAULT false,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CategoryVisit_pkey" PRIMARY KEY ("id")
);

-- Criar tabela ProductView se não existir
CREATE TABLE IF NOT EXISTS "ProductView" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "productName" TEXT NOT NULL,
    "categoryName" TEXT,
    "visits" INTEGER NOT NULL DEFAULT 1,
    "lastView" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "addedToCart" BOOLEAN NOT NULL DEFAULT false,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ProductView_pkey" PRIMARY KEY ("id")
);

-- Criar tabela SearchHistory se não existir
CREATE TABLE IF NOT EXISTS "SearchHistory" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "term" TEXT NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 1,
    "lastSearch" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "SearchHistory_pkey" PRIMARY KEY ("id")
);

-- Criar tabela CartEvent se não existir
CREATE TABLE IF NOT EXISTS "CartEvent" (
    "id" TEXT NOT NULL,
    "sessionId" TEXT NOT NULL,
    "type" "CartEventType" NOT NULL,
    "productId" TEXT NOT NULL,
    "productName" TEXT,
    "quantity" INTEGER NOT NULL,
    "unitPrice" DOUBLE PRECISION,
    "totalPrice" DOUBLE PRECISION,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CartEvent_pkey" PRIMARY KEY ("id")
);

-- Criar índices (ignorar se já existirem)
CREATE UNIQUE INDEX IF NOT EXISTS "AnalyticsSession_sessionId_key" ON "AnalyticsSession"("sessionId");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_whatsapp_idx" ON "AnalyticsSession"("whatsapp");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_lastActivity_idx" ON "AnalyticsSession"("lastActivity");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_createdAt_idx" ON "AnalyticsSession"("createdAt");

CREATE INDEX IF NOT EXISTS "PageView_sessionId_idx" ON "PageView"("sessionId");
CREATE INDEX IF NOT EXISTS "PageView_timestamp_idx" ON "PageView"("timestamp");

CREATE INDEX IF NOT EXISTS "CategoryVisit_sessionId_idx" ON "CategoryVisit"("sessionId");
CREATE INDEX IF NOT EXISTS "CategoryVisit_timestamp_idx" ON "CategoryVisit"("timestamp");
CREATE UNIQUE INDEX IF NOT EXISTS "CategoryVisit_sessionId_categoryId_key" ON "CategoryVisit"("sessionId", "categoryId");

CREATE INDEX IF NOT EXISTS "ProductView_sessionId_idx" ON "ProductView"("sessionId");
CREATE INDEX IF NOT EXISTS "ProductView_productId_idx" ON "ProductView"("productId");
CREATE INDEX IF NOT EXISTS "ProductView_timestamp_idx" ON "ProductView"("timestamp");
CREATE UNIQUE INDEX IF NOT EXISTS "ProductView_sessionId_productId_key" ON "ProductView"("sessionId", "productId");

CREATE INDEX IF NOT EXISTS "SearchHistory_sessionId_idx" ON "SearchHistory"("sessionId");
CREATE INDEX IF NOT EXISTS "SearchHistory_timestamp_idx" ON "SearchHistory"("timestamp");
CREATE UNIQUE INDEX IF NOT EXISTS "SearchHistory_sessionId_term_key" ON "SearchHistory"("sessionId", "term");

CREATE INDEX IF NOT EXISTS "CartEvent_sessionId_idx" ON "CartEvent"("sessionId");
CREATE INDEX IF NOT EXISTS "CartEvent_type_idx" ON "CartEvent"("type");
CREATE INDEX IF NOT EXISTS "CartEvent_timestamp_idx" ON "CartEvent"("timestamp");

-- Adicionar foreign keys apenas se não existirem
DO $$ BEGIN
    ALTER TABLE "PageView" ADD CONSTRAINT "PageView_sessionId_fkey" 
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("sessionId") ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE "CategoryVisit" ADD CONSTRAINT "CategoryVisit_sessionId_fkey" 
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("sessionId") ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE "ProductView" ADD CONSTRAINT "ProductView_sessionId_fkey" 
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("sessionId") ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE "SearchHistory" ADD CONSTRAINT "SearchHistory_sessionId_fkey" 
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("sessionId") ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE "CartEvent" ADD CONSTRAINT "CartEvent_sessionId_fkey" 
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("sessionId") ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Verificar se tabelas foram criadas
SELECT 'Analytics tables created successfully' as result;