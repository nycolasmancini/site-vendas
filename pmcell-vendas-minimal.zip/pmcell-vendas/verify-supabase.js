#!/usr/bin/env node

const { PrismaClient } = require('@prisma/client')

// Configurar conexão direta com Supabase
const DATABASE_URL = 'postgresql://postgres:Hexenwith556023@db.cjlylhgovnausyrzauuw.supabase.co:5432/postgres'

console.log('🔍 VERIFICAÇÃO COMPLETA DO SUPABASE')
console.log('=' * 50)
console.log('🔗 Conectando ao banco:', DATABASE_URL.replace(/:[^:]*@/, ':***@'))

async function verifyDatabase() {
  const prisma = new PrismaClient({
    datasources: {
      db: {
        url: DATABASE_URL
      }
    },
    log: ['error', 'warn'],
  })

  try {
    console.log('\n📋 1. VERIFICANDO TABELAS EXISTENTES')
    
    // Verificar todas as tabelas do schema public
    const allTables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `
    
    console.log(`✅ Total de tabelas no banco: ${allTables.length}`)
    allTables.forEach(table => {
      console.log(`   📋 ${table.table_name}`)
    })

    // Verificar especificamente tabelas de analytics
    const analyticsTables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN (
        'AnalyticsSession', 
        'PageView', 
        'CategoryVisit', 
        'ProductView', 
        'SearchHistory', 
        'CartEvent'
      )
      ORDER BY table_name;
    `
    
    console.log(`\n📊 Tabelas de Analytics encontradas: ${analyticsTables.length}/6`)
    analyticsTables.forEach(table => {
      console.log(`   ✅ ${table.table_name}`)
    })

    if (analyticsTables.length < 6) {
      console.log('❌ Algumas tabelas de analytics estão faltando!')
      return false
    }

    console.log('\n📊 2. TESTANDO ACESSO ÀS TABELAS')

    // Verificar se há dados em AnalyticsSession
    const sessionCount = await prisma.$queryRaw`
      SELECT COUNT(*) as count FROM "AnalyticsSession";
    `
    
    console.log(`📈 Total de sessões existentes: ${sessionCount[0].count}`)

    // Verificar estrutura da tabela AnalyticsSession
    const sessionColumns = await prisma.$queryRaw`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'AnalyticsSession' 
      AND table_schema = 'public'
      ORDER BY ordinal_position;
    `
    
    console.log(`📋 Colunas da AnalyticsSession: ${sessionColumns.length}`)
    sessionColumns.forEach(col => {
      console.log(`   📋 ${col.column_name} (${col.data_type}) ${col.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'}`)
    })

    console.log('\n🧪 3. TESTANDO OPERAÇÕES CRUD')

    // Testar inserção via Prisma ORM
    const testSessionId = `test_verify_${Date.now()}`
    
    const testSession = await prisma.analyticsSession.create({
      data: {
        sessionId: testSessionId,
        whatsapp: '5511999999999',
        timeOnSite: 60,
        isActive: true
      }
    })
    
    console.log('✅ Inserção via Prisma bem-sucedida:', testSession.id)

    // Testar leitura
    const foundSession = await prisma.analyticsSession.findUnique({
      where: { sessionId: testSessionId }
    })
    
    console.log('✅ Leitura via Prisma bem-sucedida:', foundSession ? 'ENCONTRADO' : 'NÃO ENCONTRADO')

    // Testar update
    const updatedSession = await prisma.analyticsSession.update({
      where: { id: testSession.id },
      data: { timeOnSite: 120 }
    })
    
    console.log('✅ Update via Prisma bem-sucedido:', updatedSession.timeOnSite)

    // Limpar dados de teste
    await prisma.analyticsSession.delete({
      where: { id: testSession.id }
    })
    
    console.log('✅ Cleanup realizado com sucesso')

    console.log('\n🎉 DIAGNÓSTICO CONCLUÍDO: BANCO FUNCIONANDO PERFEITAMENTE')
    console.log('❗ Problema está no CACHE do Vercel/Prisma em produção')
    console.log('💡 Solução: Forçar novo deployment para regenerar Prisma Client')

    return true

  } catch (error) {
    console.error('\n❌ ERRO DURANTE VERIFICAÇÃO:')
    console.error('Tipo:', error.constructor.name)
    console.error('Mensagem:', error.message)
    
    if (error.code) {
      console.error('Código:', error.code)
    }
    
    if (error.message.includes('does not exist')) {
      console.log('\n💡 DIAGNÓSTICO: Tabela realmente não existe ou nome incorreto')
      console.log('🔧 Verifique se as tabelas foram criadas com os nomes exatos')
    } else if (error.message.includes('permission')) {
      console.log('\n💡 DIAGNÓSTICO: Problema de permissões')
      console.log('🔧 Verifique as credenciais e permissões do usuário')
    } else if (error.message.includes('connection')) {
      console.log('\n💡 DIAGNÓSTICO: Problema de conexão')
      console.log('🔧 Verifique a URL de conexão e senha')
    }

    return false
  } finally {
    await prisma.$disconnect()
  }
}

verifyDatabase()
  .then((success) => {
    process.exit(success ? 0 : 1)
  })
  .catch((error) => {
    console.error('💥 Erro fatal:', error)
    process.exit(1)
  })